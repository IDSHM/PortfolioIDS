<?php
session_start();
if(!isset($_SESSION['username'])){
  header("location: index.php");
}

include("connection.php");
include("php/protect.php");

$tjcourse = $_GET['course'];

?>

<!DOCTYPE html>
<html>
<title>Admission Process Automation System</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}

.form-inline {  
  display: flex;
  flex-flow: row wrap;
  align-items: center;
}

.form-inline label {
  margin: 5px 10px 5px 0;
}

.form-inline input {
  vertical-align: middle;
  margin: 5px 10px 5px 0;
  padding: 10px;
  background-color: #fff;
  border: 1px solid #ddd;
}

.form-inline button {
  padding: 10px 20px;
  background-color: dodgerblue;
  border: 1px solid #ddd;
  color: white;
  cursor: pointer;
}

.form-inline button:hover {
  background-color: royalblue;
}

@media (max-width: 800px) {
  .form-inline input {
    margin: 10px 0;
  }
  
  .form-inline {
    flex-direction: column;
    align-items: stretch;
  }
}
</style>
<body class="w3-light-grey">

<!-- Top container -->
<div class="w3-bar w3-top w3-black w3-large" style="z-index:4">
  <button class="w3-bar-item w3-button w3-hide-large w3-hover-none w3-hover-text-light-grey" onclick="w3_open();"><i class="fa fa-bars"></i>  Menu</button>
  <a href='index.php'><span class="w3-bar-item w3-right"> <i class="fa fa-user"></i> &nbsp;Log Out</span></a>
</div>

<!-- Sidebar/menu -->
<nav class="w3-sidebar w3-collapse w3-white w3-animate-left" style="z-index:3;width:300px;" id="mySidebar"><br>
  <div class="w3-container w3-row">
    <div class="w3-col s4">
      <img src="avtar.png" class="w3-circle w3-margin-right" style="width:46px">
    </div>
    <div class="w3-col s8 w3-bar">
      <span>Welcome, <strong>Admin</strong></span><br>
    </div>
  </div>
  <hr>
  <div class="w3-container">
    <h5>Dashboard</h5>
  </div>
  <div class="w3-bar-block">
  <a href="#" class="w3-bar-item w3-button w3-padding-16 w3-hide-large w3-dark-grey w3-hover-black" onclick="w3_close()" title="close menu"><i class="fa fa-remove fa-fw"></i>  Close Menu</a>


    
    <a href="dashboard.php" class="w3-bar-item w3-button w3-padding "><i class="fa fa-users fa-fw "></i>&nbsp;&nbsp;Overview</a>

    <a href="searchuser.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-search"></i>&nbsp;&nbsp;Search User</a>

    <a href="userbycourse.php" class="w3-bar-item w3-button w3-padding "><i class="fa fa-user"></i>&nbsp;&nbsp;User By Course</a>
    

    <a href="review.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-check"></i></i>&nbsp;&nbsp;Review</a>
    <a href="scheduleinterview.php" class="w3-bar-item w3-button w3-padding "><i class="fa fa-calendar"></i></i>&nbsp;&nbsp;Schedule Interview</a>
   
    <a href="takeinterview.php" class="w3-bar-item w3-button w3-padding "><i class="fa fa-desktop"></i></i>&nbsp;&nbsp;Take Interview</a>
    <a href="approved.php" class="w3-bar-item w3-button w3-padding   w3-blue"><i class="fa fa-check"></i>&nbsp;&nbsp;Approved</a>
   
  <!--  <a href="addresult.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-plus"></i>&nbsp;&nbsp;Add Result</a>
   
    <a href="messages.php" class="w3-bar-item w3-button w3-padding "><i class="fa fa-envelope"></i>&nbsp;&nbsp;Messages</a>-->

 </div>
</nav>


<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:300px;margin-top:43px;">

  <!-- Header -->
  <header class="w3-container" style="padding-top:22px">
    <h5><b><i class="fa fa-check"></i>&nbsp;&nbsp;Approved Students</b></h5>
  </header>


  <!--SEARCH  -->
<?php
echo '
<br>
    <div style="background-color:#fff;">
        <p style="font-size :4px;">&nbsp;</p>
        <h2><b>&nbsp;&nbsp;Choose Course</b></h2> 
        <p style="font-size :4px;">&nbsp;</p>
        <form class="form-inline" action="" method="POST">
        &nbsp;&nbsp;
        <select style="height:42px;margin:0 5px;padding:10px;" name="query">
        <option value="">Select Course</option>';

        $sql_fetch_course = mysqli_query($conn,"SELECT * FROM tbl_course");
        while($result_fetch_course =  mysqli_fetch_assoc($sql_fetch_course)){
            echo "<option value=".$result_fetch_course['id'].">".$result_fetch_course['stream']."</option>";
        }
            echo '
        </select>

        <button type="submit" id="search" name="search" value="Search">Extract</button>
      </form>';

      echo "<p style='font-size:20px;text-align:left;color:Red;margin:5px 0px 10px 15px;'>Press <b>Ctrl + F</b> to Search Any User</p>";

if(isset($_POST['search']))
{
  $query = $_POST['query'];

  echo "
  <br>
  <table border=0 style='text-align:left;font-family:verdana;margin-left:1.2%;' width='100%'>
  <tr height='45px'>
  <td colspan='3' style='color:red;font-size:20px;
  font-weight:700;text-transform:uppercase'><center>
    ";

    $sqlfetchbycourse = mysqli_query($conn,"SELECT * FROM tbl_course WHERE `id` = '{$query}'");
    while($resultfetchbycourse =  mysqli_fetch_assoc($sqlfetchbycourse)){
        echo $resultfetchbycourse['stream'];
    }

    echo "
  </center>
    </td>
  </tr>
      <tr height='45px'>
      <th>User Name</th>
      <th>User Phone</th>
      <th>User Email</th>
      <th>Status<th>
      <th></th>
      </tr>";

  $querysearchcourse = mysqli_query($conn,"SELECT * FROM tbl_admission WHERE `std_courseid` = '{$query}'");
  if(mysqli_num_rows($querysearchcourse) != 0){
    while($resultsearchcourse  = mysqli_fetch_assoc($querysearchcourse)){
    
        $tjtmpuserid = $resultsearchcourse['std_enrollid'];
    
        $sqluserdetails = mysqli_query($conn,"SELECT * FROM tbl_account WHERE `std_enrollid` = '{$tjtmpuserid}'");
        $resultuserdetails = mysqli_fetch_assoc($sqluserdetails);
  
        $sqlfetchstatus = mysqli_query($conn,"SELECT * FROM tbl_status WHERE `std_enrollid` = '{$tjtmpuserid}'");
        $resultfetchstatus = mysqli_fetch_assoc($sqlfetchstatus);
  
        if($resultfetchstatus['std_approval'] == 1){
          echo "
                  <tr height='45px'>
                  <td>".$resultuserdetails['std_name']."</td>
                  <td>".$resultuserdetails['std_phone']."</td>
                  <td>".$resultuserdetails['std_email']."</td>
                  <td style='color:green;'>Approved</td>
                  <td><a href='doreview.php?id=".$resultuserdetails['std_enrollid']."'><button style='background:green;
                  color:white;
                  cursor:pointer;
                  border:none;
                  padding:5px 25px'>View</button></a></td>
                  </tr>";
        }   
    }
  }else{
    echo "
                <tr height='45px'>
                <td colspan='3'><h3 style='text-align:center;color:Red;'>No User Found !</h3></td>
                </tr>";
  }



  echo "</table>";
}else{
  $query = "";

  echo "
  <br>
  <table border=0 style='text-align:left;font-family:verdana;margin-left:1.2%;' width='100%'>
      <tr height='45px'>
      <th>User Name</th>
      <th>User Phone</th>
      <th>User Email</th>
      <th>Status<th>
      <th></th>
      </tr>";

  $querysearchcourse = mysqli_query($conn,"SELECT * FROM tbl_admission");

  if(mysqli_num_rows($querysearchcourse) != 0){
    while($resultsearchcourse  = mysqli_fetch_assoc($querysearchcourse)){
    
      $tjtmpuserid = $resultsearchcourse['std_enrollid'];
  
      $sqluserdetails = mysqli_query($conn,"SELECT * FROM tbl_account WHERE `std_enrollid` = '{$tjtmpuserid}'");
      $resultuserdetails = mysqli_fetch_assoc($sqluserdetails);

      $sqlfetchstatus = mysqli_query($conn,"SELECT * FROM tbl_status WHERE `std_enrollid` = '{$tjtmpuserid}'");
      $resultfetchstatus = mysqli_fetch_assoc($sqlfetchstatus);

      if($resultfetchstatus['std_approval'] == 1){
        echo "
                <tr height='45px'>
                <td>".$resultuserdetails['std_name']."</td>
                <td>".$resultuserdetails['std_phone']."</td>
                <td>".$resultuserdetails['std_email']."</td>
                <td style='color:green;'>Approved</td>
                <td><a href='view.php?id=".$resultuserdetails['std_enrollid']."&page=approval'><button style='background:green;
                color:white;
                cursor:pointer;
                border:none;
                padding:5px 25px'>View</button></a></td>
                </tr>";
      }  
    }
  }else{
    echo "
                <tr height='45px'>
                <td colspan='3'><h3 style='text-align:center;color:Red;'>No User Found !</h3></td>
                </tr>";
  }



  echo "</table>";
}
 
?>
</div>



  <!-- End page content -->
</div>

<script>
// Get the Sidebar
var mySidebar = document.getElementById("mySidebar");

// Get the DIV with overlay effect
var overlayBg = document.getElementById("myOverlay");

// Toggle between showing and hiding the sidebar, and add overlay effect
function w3_open() {
  if (mySidebar.style.display === 'block') {
    mySidebar.style.display = 'none';
    overlayBg.style.display = "none";
  } else {
    mySidebar.style.display = 'block';
    overlayBg.style.display = "block";
  }
}

// Close the sidebar with the close button
function w3_close() {
  mySidebar.style.display = "none";
  overlayBg.style.display = "none";
}



</script>

</body>
</html>
