let pswCheckBox = document.getElementById("showpsw");
let psw = document.getElementById("psw");

pswCheckBox.addEventListener("change",()=>{
    if(pswCheckBox.checked == true){
        psw.type = "text";
    }else{
        psw.type = "password";
    }
});