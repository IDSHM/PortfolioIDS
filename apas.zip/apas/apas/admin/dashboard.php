<?php
session_start();
if(!isset($_SESSION['username'])){
  header("location: index.php");
}

include("connection.php");

$queryusers = "SELECT * FROM `tbl_account`";
$datausers = mysqli_query($conn,$queryusers);
$totalusers = mysqli_num_rows($datausers);

$queryforms = "SELECT * FROM `tbl_admission`";
$dataforms = mysqli_query($conn,$queryforms);
$totalforms = mysqli_num_rows($dataforms);
?>

<!DOCTYPE html>
<html>
<title>Admission Process Automation System</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
</style>
<body class="w3-light-grey">

<!-- Top container -->
<div class="w3-bar w3-top w3-black w3-large" style="z-index:4">
  <button class="w3-bar-item w3-button w3-hide-large w3-hover-none w3-hover-text-light-grey" onclick="w3_open();"><i class="fa fa-bars"></i>  Menu</button>
  <a href='index.php'><span class="w3-bar-item w3-right"> <i class="fa fa-user"></i> &nbsp;Log Out</span></a>
</div>

<!-- Sidebar/menu -->
<nav class="w3-sidebar w3-collapse w3-white w3-animate-left" style="z-index:3;width:300px;" id="mySidebar"><br>
  <div class="w3-container w3-row">
    <div class="w3-col s4">
      <img src="avtar.png" class="w3-circle w3-margin-right" style="width:46px">
    </div>
    <div class="w3-col s8 w3-bar">
      <span>Welcome, <strong>Admin</strong></span><br>
    </div>
  </div>
  <hr>
  <div class="w3-container">
    <h5>Dashboard</h5>
  </div>
  <div class="w3-bar-block">
    <a href="#" class="w3-bar-item w3-button w3-padding-16 w3-hide-large w3-dark-grey w3-hover-black" onclick="w3_close()" title="close menu"><i class="fa fa-remove fa-fw"></i>  Close Menu</a>


    
    <a href="dashboard.php" class="w3-bar-item w3-button w3-padding w3-blue"><i class="fa fa-users fa-fw "></i>&nbsp;&nbsp;Overview</a>

    <a href="searchuser.php" class="w3-bar-item w3-button w3-padding "><i class="fa fa-search"></i>&nbsp;&nbsp;Search User</a>

    <a href="userbycourse.php" class="w3-bar-item w3-button w3-padding "><i class="fa fa-user"></i>&nbsp;&nbsp;User By Course</a>

    <a href="review.php" class="w3-bar-item w3-button w3-padding "><i class="fa fa-check"></i></i>&nbsp;&nbsp;Review</a>

    <a href="scheduleinterview.php" class="w3-bar-item w3-button w3-padding "><i class="fa fa-calendar"></i></i>&nbsp;&nbsp;Schedule Interview</a>

    <a href="takeinterview.php" class="w3-bar-item w3-button w3-padding "><i class="fa fa-desktop"></i></i>&nbsp;&nbsp;Take Interview</a>
    
    <a href="approved.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-check"></i>&nbsp;&nbsp;Approved</a>
   
    <!--  <a href="addresult.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-plus"></i>&nbsp;&nbsp;Add Result</a>
   
    <a href="messages.php" class="w3-bar-item w3-button w3-padding "><i class="fa fa-envelope"></i>&nbsp;&nbsp;Messages</a>-->
  </div>
</nav>


<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:300px;margin-top:43px;">

  <!-- Header -->
  <header class="w3-container" style="padding-top:22px">
    <h5><b><i class="fa fa-dashboard"></i> My Dashboard</b></h5>
  </header>

  <div class="w3-row-padding w3-margin-bottom">
  <div class="w3-quarter">
      <div class="w3-container w3-orange w3-text-white w3-padding-16">
        <div class="w3-left"><i class="fa fa-user w3-xxxlarge"></i></div>
        <div class="w3-right">
          <h3><?php echo $totalusers;?></h3>
        </div>
        <div class="w3-clear"></div>
        <h4>Registered Users</h4>
      </div>
    </div>

    
    <div class="w3-quarter">
      <div class="w3-container w3-red w3-padding-16">
        <div class="w3-left"><i class="fa fa-users w3-xxxlarge"></i></div>
        <div class="w3-right">
          <h3><?php echo $totalforms;?></h3>
        </div>
        <div class="w3-clear"></div>
        <h4>User's Filled Form</h4>
      </div>
    </div>

 
    <!-- <div class="w3-quarter">
      <div class="w3-container w3-blue w3-padding-16">
        <div class="w3-left"><i class="fa fa-comment w3-xxxlarge"></i></div>
        <div class="w3-right">
          <h3><?php echo "0";?></h3>
        </div>
        <div class="w3-clear"></div>
        <h4>Messages</h4>
      </div>
    </div> -->

   
  </div>

  <hr>

  <!-- Header -->
  <header class="w3-container" style="padding-top:22px">
    <h5><b><i class="fa fa-dashboard "></i>Admission Form Filled by Courses</b></h5>
  </header>

  <div class="w3-row-padding w3-margin-bottom">
<?php
  $sqlCourse = mysqli_query($conn,"SELECT * FROM `tbl_course`");

  while($resultCourse = mysqli_fetch_assoc($sqlCourse)){
    echo '<div class="w3-quarter" style="border:1px solid grey;margin:10px;">
    <div class="w3-container w3-text-black w3-padding-16">
    <div class="w3-left">
      <h4><a style="text-decoration:none;" href=""><b>'.substr($resultCourse['stream'],0,24).'</b></a></h4></div>
      <div class="w3-right">
        <h3>';

        $course_id = $resultCourse['id'];

        $sqlCount = mysqli_query($conn,"SELECT `std_enrollid` FROM `tbl_admission` WHERE `std_courseid` = {$course_id}");

        if (mysqli_num_rows($sqlCount) > 0) {
          $tj = mysqli_num_rows($sqlCount);
          echo $tj;
        }else {
          echo "0";
        }

        $sqlcountbycourse = mysqli_query($conn,"SELECT `std_enrollid` FROM `tbl_admission` WHERE `std_courseid` = {$course_id}");

        $totalreview = 0;
        $totalinterview = 0;
        $totalapproved = 0;


        while($resultcoursebycourse = mysqli_fetch_assoc($sqlcountbycourse)){
          $tjTmp = $resultcoursebycourse['std_enrollid'];

          $sqlreview = mysqli_query($conn,"SELECT `std_enrollid` FROM `tbl_status` WHERE `std_review` = 1 AND `std_enrollid` = {$tjTmp}");
          if(mysqli_num_rows($sqlreview) > 0){
            $totalreview++;
          }

          $sqlinterview = mysqli_query($conn,"SELECT `std_enrollid` FROM `tbl_status` WHERE `std_interview` = 1 AND `std_enrollid` = {$tjTmp}");
          if(mysqli_num_rows($sqlinterview) > 0){
            $totalinterview++;
          }


          $sqlapproved = mysqli_query($conn,"SELECT `std_enrollid` FROM `tbl_status` WHERE `std_approval` = 1  AND `std_enrollid` = {$tjTmp}");
          if(mysqli_num_rows($sqlapproved) > 0){
            $totalapproved++;
          }
        }

       


        
        echo '</h3>
      </div>
    </div>

    <div class="bottom" style="display:flex;
    justify-content:space-between;
    align-items:center;
    padding:0 15px "> 
    <p><b style="color:black">Review Done: '.$totalreview.'</b></p> <p><b style="color:tomato">Interview Done: '.$totalinterview.'</b></p><p><b style="color:green">Approved: '.$totalapproved .'</b></p>
    </div>
  
  </div>';
  }


    // $sql = "SELECT * FROM `tbl_event`";
    // $result = mysqli_query($conn, $sql);
    // if (mysqli_num_rows($result) > 0) {
    //   // output data of each row
    //   while($row = mysqli_fetch_assoc($result)) {
      //   echo '<div class="w3-quarter">
      //   <div class="w3-container w3-text-black w3-padding-16">
      //   <div class="w3-left">
      //     <h4><a style="text-decoration:none;" href="php/export.php?eventid='.$row['event_id'].'"><b>'.$row['event_name'].'</b></a></h4></div>
      //     <div class="w3-right">
      //       <h3>';

      //       $event_id = $row['event_id'];
      //       $sql_num = "SELECT DISTINCT(`user_id`),`event_id` FROM `tbl_register` WHERE `event_id` = {$event_id}";
      //       $result_num = mysqli_query($conn, $sql_num);
      //       if (mysqli_num_rows($result_num) > 0) {
      //         $tj = mysqli_num_rows($result_num);
      //         echo $tj;
      //       }else {
      //         echo "0 results";
      //       }
            
      //       echo '</h3>
      //     </div>
      //   </div>
      // </div>';
    //   }
    // } else {
    //   echo "0 results";
    // }
?>
  </div>

  <hr>


  


  <!-- End page content -->
</div>

<script>
// Get the Sidebar
var mySidebar = document.getElementById("mySidebar");

// Get the DIV with overlay effect
var overlayBg = document.getElementById("myOverlay");

// Toggle between showing and hiding the sidebar, and add overlay effect
function w3_open() {
  if (mySidebar.style.display === 'block') {
    mySidebar.style.display = 'none';
    overlayBg.style.display = "none";
  } else {
    mySidebar.style.display = 'block';
    overlayBg.style.display = "block";
  }
}

// Close the sidebar with the close button
function w3_close() {
  mySidebar.style.display = "none";
  overlayBg.style.display = "none";
}
</script>

</body>
</html>
