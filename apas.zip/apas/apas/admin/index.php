<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admission Process Automation System</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <div class="wrapper">
    <section class="form login">
        <form action="" class="form">
            <header>Admin Login</header>
            <div class="errortext">Errors</div>
            <div class="getdata">
                <div class="getinput">
                     <input type="text" name="username" placeholder="Enter Email" required>
                </div>
                <div class="getinput">
                      <input type="password" name="psw" id='psw' placeholder="Password" required>
                      <p style='font-size:9px;'>&nbsp;</p>&nbsp;
                      <input type="checkbox" onclick="showpsw()">&nbsp;<span style='color:grey;'>Show Password</span>
                </div>
                <div class="submitbtn button">
                    <center><input type="submit" value="Log In"></center>
                </div>

              
                
            </div>
        </form>
        </section>
    </div>

    <script src="js/showpassword.js"></script>
    <script src="js/login.js"></script>
</body>
</html>