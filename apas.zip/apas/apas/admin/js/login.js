const form = document.querySelector(".login form"),
continueBtn = form.querySelector(".button input"),
errorText = form.querySelector(".errortext");

form.onsubmit = (e)=>{
    e.preventDefault(); //preventing form from reloading;
}

continueBtn.onclick = ()=>{
  //--- AJAX ---
  let xhr = new XMLHttpRequest(); // creating XML Object
  xhr.open("POST", "php/login.php", true);
  xhr.onload = ()=>{
    if(xhr.readyState === XMLHttpRequest.DONE){
        if(xhr.status === 200){
            let data = xhr.response;
            if(data === "success"){
              location.href="dashboard.php";
            }
            else{
                errorText.style.display = "block";
                errorText.textContent = data;
               // location.href="users.php";
            }
        }
    }
  }
  // sending form data through ajax to php
  let formData = new FormData(form); //creating form object
  xhr.send(formData);  //sending the form data to php
}