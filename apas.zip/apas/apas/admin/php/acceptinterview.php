<?php
session_start();
if(!isset($_SESSION['username'])){
  header("location: ../index.php");
}

include("../connection.php");
include("protect.php");

$userid = $_GET['id'];

$sql_accpet = mysqli_query($conn,"UPDATE `tbl_status` SET `std_approval`='1' WHERE `std_enrollid`='{$userid}'");

if($sql_accpet){
    // echo "<script>
    // alert('Accepted Application...!');

    // window.location.replace('../approved.php');

    // </script>";

    // Email System
    if($email_status == 0){
      echo "<script>alert('Accepted Application...!');
    window.location.replace(`../approved.php`);</script>";
    }else{

      $sql_details = mysqli_query($conn,"SELECT * FROM `tbl_account` WHERE `std_enrollid` =  '{$userid}'");
      if(mysqli_num_rows($sql_details) > 0)
      {
          $result_details = mysqli_fetch_assoc($sql_details);
      }

      echo '

      <script type="text/javascript"
      src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>
      
      <script>
    
      emailjs.init("JZXjyLlOrXEB1DddM");
  
      emailjs.send("service_pozrraa","template_8s7uztn",{
        subject: `Interview Result - APAS`,
        to: `'.$result_details["std_email"].'`,
        msg1: `Hi '.$result_details["std_name"].' !`,
        msg2: `Your Application is APPROVED !!!`,
        msg3: `!!! Congratulations For Becoming Member of PCTE Family`,
        msg4: ``,
        msg5: `Please Visit View Form Section on Dashboard to Download Your Application.`,
        link: ``,
      }).then(() => {
        alert("Accepted Application -> Mailed Also...!");
    window.location.replace("../approved.php");
        },(err) => {
          alert("Accepted Application...!");
    window.location.replace("../approved.php");
    });
  
      </script>';
    }


}else{
    echo "<script>
    alert('Not Able To Accept...!');

    window.location.replace('../approved.php');

    </script>";
}



?>