<?php
    include("../connection.php");
    session_start();
    if(!isset($_SESSION['username'])){
    header("location: ../index.php");
    }
    //error_reporting(0);

    $html = "";

    $event_id = $_GET['eventid'];

    $query_en = "SELECT `event_name` FROM `tbl_event` WHERE `event_id` = {$event_id}";
    $data_en  = mysqli_query($conn,$query_en);
    $resul_en  = mysqli_fetch_assoc($data_en);
    
    $queryp = "SELECT * FROM `tbl_register` WHERE `event_id` = {$event_id}";
    $datap  = mysqli_query($conn,$queryp);
    $totalp  = mysqli_num_rows($datap);
    if($totalp != 0)
    {
      $team = 1;
      $html .="
      <table border=1>
      <tr>
      <td colspan='7'><center><b>".strtoupper($resul_en['event_name'])."</b></center></td>
      </tr>
          <tr height='50px'>
          <th width='102px'><center>Team No.</center></th>
          <th width='170px'>Participant Name</th>
          <th width='80px'><center>Total Participants</center></th>
          <th>Participant Collage</th>
          <th>Participant Teacher</th>
          <th width='180px'>Participant Phone</th>
          <th width='250px'>Participant Email</th>
          </tr>";
        while($resultp  = mysqli_fetch_assoc($datap)){
            $html .= "<tr> ";

              $tmp = $resultp['user_id'];

              $queryc = "SELECT * FROM `tbl_teacher` WHERE `user_id` = {$tmp}";
              $datac  = mysqli_query($conn,$queryc);
              $resultc  = mysqli_fetch_assoc($datac);

              $tmp_collage = $resultc['collage_name'].", ".$resultc['collage_city'].", ".$resultc['collage_state'].", ".$resultc['collage_pincode'];

              $tmp_teacher = $resultc['teach_name']." (".$resultc['teach_email'].", ".$resultc['teach_phone'].")";


              if($resultp['p_no'] == $resultp['p_count'] && $resultp['p_count'] == 1){
                $html .= " <td align='center' valign='middle'><center>".$team."</center></td>";
                $html .= "
                    <td>".$resultp['p_name']."</td>
                    <td>".$resultp['p_count']."</td>
                    <td>".$tmp_collage."</td>
                    <td>".$tmp_teacher."</td>
                    <td>".$resultp['p_mobile']."</td>
                    <td>".$resultp['p_email']."</td>
                    </tr>";
                    $team++; 
              }
              else{
                if($resultp['p_no'] == 1){
                  $html .= "<td rowspan='".$resultp['p_count']."'><center>".$team."</center></td>";
                  $html .= "
                  <td>".$resultp['p_name']."</td>
                  <td rowspan='".$resultp['p_count']."'><center>".$resultp['p_count']."</center></td>
                  <td rowspan='".$resultp['p_count']."'>".$tmp_collage."</td>
                  <td rowspan='".$resultp['p_count']."'>".$tmp_teacher."</td>
                  <td>".$resultp['p_mobile']."</td>
                  <td>".$resultp['p_email']."</td>
                  </tr>";
                  $team++;
                }
                else{
                  $html .= "
                  <td>".$resultp['p_name']."</td>
                  <td>".$resultp['p_mobile']."</td>
                  <td>".$resultp['p_email']."</td>
                  </tr>";
                }
            }  
        }
        $html .= "</table>";
    }

    echo $html;
    header('Content-Type:application/doc');
    header('Content-Disposition:attachment;filename=Ehsaas_'.$resul_en['event_name'].'.doc');
?>