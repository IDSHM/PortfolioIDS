<?php 
    session_start();
    include_once "../connection.php";

    $username = mysqli_real_escape_String($conn, $_POST['username']);
    $password = mysqli_real_escape_String($conn, $_POST['psw']);

    if(!empty($username) && !empty($password)){
            if($username == "tejindergahir19@gmail.com" || $username == "@admin")
            {
                if($password == "apas")
                {
                    $_SESSION['username'] = $username;
                    echo "success";
                }
                else
            {
                echo "Incorrect Password";
            }
            }
            else
            {
                echo "Incorrect Username";
            }
        }
    else{
        echo "All Fields Are Required !";
    }
?>