<?php
function EncryptData($simple_string)
{
    $ciphering = "AES-128-CTR";
    $iv_length = openssl_cipher_iv_length($ciphering);
    $options = 0;
    $encryption_iv = '1234567891011121';
    $encryption_key = "tejindergahir19";
    $encryption = openssl_encrypt($simple_string, $ciphering,$encryption_key, $options, $encryption_iv);
    return $encryption;
}

function DecryptData($simple_string)
{
    $ciphering = "AES-128-CTR";
    $iv_length = openssl_cipher_iv_length($ciphering);
    $options = 0;
    $decryption_iv = '1234567891011121';
    $decryption_key = "tejindergahir19";
    $decryption=openssl_decrypt($simple_string, $ciphering,$decryption_key, $options, $decryption_iv);
    return  $decryption;
}
?>