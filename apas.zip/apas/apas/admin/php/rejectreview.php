<?php
session_start();
if(!isset($_SESSION['username'])){
  header("location: ../index.php");
}

include("../connection.php");
include("protect.php");

$userid = $_GET['id'];
$msg = $_GET['msg'];

$sql_accpet = mysqli_query($conn,"UPDATE `tbl_status` SET `std_review`='-1',`std_rejectionmsg` = '{$msg}'  WHERE `std_enrollid`='{$userid}'");

if($sql_accpet){
    // echo "<script>
    // alert('Rejected Application...!');

    // window.location.replace('../doreview.php?id=".$userid."');

    // </script>";

    // Email System
    if($email_status == 0){
      echo "<script>alert('Rejected Application...!');
    window.location.replace(`../doreview.php?id=".$userid."`);</script>";
    }else{

      $sql_details = mysqli_query($conn,"SELECT * FROM `tbl_account` WHERE `std_enrollid` =  '{$userid}'");
      if(mysqli_num_rows($sql_details) > 0)
      {
          $result_details = mysqli_fetch_assoc($sql_details);
      }

      echo '

      <script type="text/javascript"
      src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>
      
      <script>
    
      emailjs.init("JZXjyLlOrXEB1DddM");
  
      emailjs.send("service_pozrraa","template_8s7uztn",{
        subject: `Application Reviewed - APAS`,
        to: `'.$result_details["std_email"].'`,
        msg1: `Hi '.$result_details["std_name"].' !`,
        msg2: ``,
        msg3: `We have Reviewed your Application and Your are NOT SELECTED.`,
        msg4: `Reason: '.$msg.'`,
        msg5: ``,
        link: ``,
      }).then(() => {
        alert("Rejected Application -> Mailed Also...!");
    window.location.replace("../doreview.php?id='.$userid.'");
        },(err) => {
          alert("Rejected Application...!");
    window.location.replace("../doreview.php?id='.$userid.'");
    });
  
      </script>';
    }




}else{
    echo "<script>
    alert('Not Able To Reject...!');

    window.location.replace('../doreview.php?id=".$userid."');

    </script>";
}



?>