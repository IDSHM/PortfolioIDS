<?php
session_start();
if(!isset($_SESSION['username'])){
  header("location: ../index.php");
}

include("../connection.php");
include("protect.php");

$userid = $_GET['id'];
$link = $_GET['link'];
$dateTime = $_GET['dateTime'];

$sql_accpet = mysqli_query($conn,"UPDATE `tbl_status` SET `std_interview`='1' , `interview_link` = '{$link}', `interview_datetime` = '{$dateTime}' WHERE `std_enrollid`='{$userid}'");

if($sql_accpet){
    // echo "<script>
    // alert('Interview Scheduled...!');

    // window.location.replace('../takeinterview.php');

    // </script>";


    // Email System
    if($email_status == 0){
      echo "<script>alert('Interview Scheduled...!');
    window.location.replace(`../takeinterview.php`);</script>";
    }else{

      $sql_details = mysqli_query($conn,"SELECT * FROM `tbl_account` WHERE `std_enrollid` =  '{$userid}'");
      if(mysqli_num_rows($sql_details) > 0)
      {
          $result_details = mysqli_fetch_assoc($sql_details);
      }

      $tjdate=date_create($dateTime);
      $tjdatefinal = date_format($tjdate,"d-M-Y h:i A");

      echo '

      <script type="text/javascript"
      src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>
      
      <script>
    
      emailjs.init("JZXjyLlOrXEB1DddM");
  
      emailjs.send("service_pozrraa","template_8s7uztn",{
        subject: `Interview - APAS`,
        to: `'.$result_details["std_email"].'`,
        msg1: `Hi '.$result_details["std_name"].' !`,
        msg2: `Your ONLINE INTERVIEW is Scheduled on '.$tjdatefinal.'`,
        msg3: ``,
        msg4: `Please click on the link below to Join for Interview or you can directly join from dashboard.`,
        msg5: ``,
        link: `'.$link.'`,
      }).then(() => {
        alert("Interview Scheduled -> Mailed Also...!");
    window.location.replace("../takeinterview.php");
        },(err) => {
          alert("Interview Scheduled...!");
    window.location.replace("../takeinterview.php");
    });
  
      </script>';
    }



}else{
    echo "<script>
    alert('Not Able To Schedule...!');

    window.location.replace('../scheduleinterview.php');

    </script>";
}



?>