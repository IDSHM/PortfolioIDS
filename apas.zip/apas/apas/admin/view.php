<?php
session_start();
if(!isset($_SESSION['username'])){
  header("location: index.php");
}

include("connection.php");
include("php/protect.php");

$userid = $_GET['id'];

$sql_user = mysqli_query($conn,"SELECT * FROM tbl_account WHERE `std_enrollid` = '{$userid}'");
$result_user = mysqli_fetch_assoc($sql_user );

$sql_formdetails = mysqli_query($conn,"SELECT * FROM `tbl_admission` WHERE `std_enrollid` =  '{$userid}'");
if(mysqli_num_rows($sql_formdetails) > 0)
{
    $result_formdetails = mysqli_fetch_assoc($sql_formdetails);
}

$sql_status = mysqli_query($conn,"SELECT * FROM tbl_status WHERE `std_enrollid` = '{$userid}'");
$result_status = mysqli_fetch_assoc($sql_status);



?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>VIEW USER INFORMATION</title>

  <!-- Internal Css Files -->
  <link rel="stylesheet" href="assets/css/register-form.css">
  <link rel="stylesheet" href="assets/css/header.css" />
  <link rel="stylesheet" href="assets/css/dashboard.css">
  <link rel="stylesheet" href="assets/css/admissionform.css">
  <link rel="stylesheet" href="assets/css/uploaddocuments.css">

  <!-- Fancy Box -->
  <link rel="stylesheet" href="assets/css/fancybox.css">



  <!-- Font-Awesome Icons -->
  <script src="https://kit.fontawesome.com/40963500f2.js" crossorigin="anonymous"></script>

  <style>
    section .basicdetails .table table td{
    border:1px solid #CCC9B6;
    margin:0;
}
section .basicdetails .table table th{
    width:200px;
}
  </style>
</head>

<body>

<header>
    <div class="mini-nav">
      
    </div>

    <nav>
      <div class="logo">
        <img src="assets/logo.png" alt="" />
        <div class="collage-name">
          <a href="#">
            <!-- <p class="head-small"></p> -->
            <p class="head-big">Admission Process Automation System</p>
          </a>
        </div>
      </div>
      <div class="nav">
        <?php 



    if($_GET['page'] == 'approval'){
        echo '<a href="approved.php" class="login-btn">Back</a>';
    }else if($_GET['page'] == 'search'){
        echo '<a href="searchuser.php" class="login-btn">Back</a>';
    }else{
        echo '<a href="userbycourse.php" class="login-btn">Back</a>';
    }


        ?>

        
      </div>
    </nav>
  </header>


  <div class="container">
    <section>
      <div class="welcome">
        <h2>Admission Form</h2>
        <p><span>Get Your Self Registered with APAS</span></p>
      </div>

      <section>
        <div class="basicdetails">
            <div class="table">
                <table border="0" style="border:none;">
                <tr>
                    <td colspan="2" style="border:none;text-align:right;color:red;"><b>DateTime : </b>31-07-22 10:57:33</td>
                </tr>
                <tr>
                    <th>Form No.</th>
                    <td style="color:red;"><b><?php echo $userid; ?></b></td>
                </tr></table>


                <table border="0" style="border:none;">
                    <tr>
                        <th>Name</th>
                        <td><?php echo $result_user['std_name']; ?></td>
                        <td rowspan="5" width="146px">
                            <img src="../documents/photo/<?php echo $userid;?>.jpg" width="100%" height="100%" alt="">
                        </td>
                    </tr>
                    <tr>
                        <th>Age</th>
                        <td><?php
                                # object oriented
$from = date_create($result_user['std_dob']);
$to   = new DateTime('today');
echo $from->diff($to)->y;
                              ?></td>
                    </tr>
                    <tr>
                        <th>Gender</th>
                        <td><?php echo ($result_user['std_gender'] == "M") ? "Male" : "Female";?></td>
                    </tr>
                    <tr>
                        <th>DOB</th>
                        <td> <?php 
                              $date=date_create($result_user['std_dob']);
                              echo date_format($date,"d / M / Y");
                            ?></td>
                    </tr>
                    <tr>
                        <th>Blood Group</th>
                        <td><?php echo $result_formdetails['std_bloodgroup'];?></td>
                    </tr>
                </table>

                <table border="0" style="border:none;">
                    <tr>
                        <th>Category</th>
                        <td width="265px"><?php echo $result_formdetails['std_category'];?></td>
                        <th>Religion</th>
                        <td><?php echo $result_formdetails['std_religion'];?></td>
                    </tr>
                <tr>
                    <th>Martial Status</th>
                    <td colspan="3"><?php echo ($result_formdetails['std_martialstatus'] == 1) ? "Married" : "Unmarried";?></td>
                </tr></table>

                <table border="0" style="border:none;">
                    <tr>
                        <th>Email</th>
                        <td><?php echo $result_user['std_email'];?></td>
                    </tr>
                <tr>
                    <th>Phone</th>
                    <td ><?php echo $result_user['std_phone'];?></td>
                </tr></table>

                <table border="0" style="border:none;">
                    <tr>
                        <th>Father's Name</th>
                        <td><?php echo $result_formdetails['std_fathername'];?></td>
                    </tr>
                <tr>
                    <th>Mother's Name</th>
                    <td ><?php echo $result_formdetails['std_mothername'];?></td>
                </tr>
                
                <tr>
                    <th>Parent's Email</th>
                    <td ><?php echo $result_formdetails['std_parentemail'];?></td>
                </tr>
                <tr>
                    <th>Parent's Phone</th>
                    <td ><?php echo $result_formdetails['std_parentphone'];?></td>
                </tr>
            </table>

            <table border="0" style="border:none;">
                <tr>
                    <th>House No.</th>
                    <td width="265px"><?php echo $result_formdetails['std_housenumber'];?></td>
                    <th>Village / Locality</th>
                    <td><?php echo $result_formdetails['std_village'];?></td>
                </tr>
                <tr>
                    <th>City</th>
                    <td width="265px"><?php echo $result_formdetails['std_city'];?></td>
                    <th>State</th>
                    <td><?php echo $result_formdetails['std_state'];?></td>
                </tr>
                <tr>
                    <th>Country</th>
                    <td width="265px"><?php echo $result_formdetails['std_country'];?></td>
                    <th>Pin Code</th>
                    <td><?php echo $result_formdetails['std_pincode'];?></td>
                </tr>
        </table>

        <table border="0" style="border:none;">
            <tr>
                <th>Aadhar No.</th>
                <td><?php echo $result_formdetails['std_aadharnumber'];?></td>
            </tr>
    </table>

    <table border="0" style="border:none;">
        <tr>
            <th>Exam Passed</th>
            <th>Board</th>
            <th >Year of Passing</th>
            <th>Percentage (%)</th>
          </tr>
          <tr>
            <td >10th</td>
            <td><?php echo $result_formdetails['std_tenth_board'];?></td>
            <td ><?php echo $result_formdetails['std_tenth_yop'];?></td>
            <td><?php echo $result_formdetails['std_tenth_per'];?></td>
          </tr>
          <tr>
            <td>12th</td>
            <td><?php echo $result_formdetails['std_twelve_board'];?></td>
            <td><?php echo $result_formdetails['std_twelve_yop'];?></td>
            <td><?php echo $result_formdetails['std_twelve_per'];?></td>
          </tr>
</table>

<table border="0" style="border:none;">
    <tr>
        <th>Course</th>
<td>
<?php
$courseid = $result_formdetails['std_courseid'];

 $sql_fetchcourse = mysqli_query($conn,"SELECT * FROM `tbl_course` WHERE `id` = '{$courseid}'");
 if(mysqli_num_rows($sql_fetchcourse) > 0)
 {
     $result_fetchcourse = mysqli_fetch_assoc($sql_fetchcourse);
       echo ($result_fetchcourse['course'] == "ug") ? "UG" : "PG";
       echo " - ".$result_fetchcourse['stream'];
 }
?>


</td>
      </tr>
</table>


<?php
if($result_status['std_approval'] == 1){
    echo '<table border="0" style="border:none;">
    <tr>
        <th>Application</th>
        <td style="color:green;"><b>Accepted</b></td>
      </tr>
</table>';
}else if($result_status['std_approval'] == -1 || $result_status['std_review'] == -1){
    echo '<table border="0" style="border:none;">
    <tr>
        <th>Application</th>
        <td style="color:red;"><b>Rejected - '.$result_status['std_rejectionmsg'].'</b></td>
      </tr>
</table>';
}

?>


            </div>    
        </div>
    </section>
    </section>

    <section style="padding-top:1px">

<div class="register">
  <div class="form">
    <form>
      <h1 style="color:#F03C02">Document Uploaded</h1>

      <div class="document">
        <div class="aadhar">
          <a class="img" data-fancybox="gallery" href="../documents/aadhar/<?php echo $userid;?>.jpg">
            <img height="500px"  src="../documents/aadhar/<?php echo $userid;?>.jpg" alt="" />
</a>
        </div>
        <div class="tenth">
        <a class="img" data-fancybox="gallery" href="../documents/tenth/<?php echo $userid;?>.jpg">
          <img height="500px"  src="../documents/tenth/<?php echo $userid;?>.jpg" alt="" />
</a>
        </div>
        <div class="twelve">
        <a class="img" data-fancybox="gallery" href="../documents/twelve/<?php echo $userid;?>.jpg">
          <img height="500px"  src="../documents/twelve/<?php echo $userid;?>.jpg" alt="" />
</a>
        </div>
      </div>
    </form>
  </div>
</div>

<br><br>


<br><br>
            <div class="buttons" style="justify-content:center;">
                <button style="background-color: #037D03;" type="button" onclick="window.print();">Print</button>
            </div>  
</section>




  </div>


  <script src="assets/js/jquery.js"></script>
  <script src="assets/js/fancybox.js">
    
  </script>

</body>
</html>