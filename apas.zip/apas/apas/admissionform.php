<?php 
    session_start();
    include_once "php/connection.php";
  //  error_reporting(0);

  if(!isset($_SESSION['std_enrollid'])){
   echo '
   <script>window.location.replace("./login.php")</script>;
   ';
  }

   $user_id = $_SESSION['std_enrollid'];

   $sql_details = mysqli_query($conn,"SELECT `std_enrollid`, `std_datetime`, `std_name`, `std_gender`, `std_dob`, `std_email`, `std_phone` FROM `tbl_account` WHERE `std_enrollid` =  '{$user_id}'");
    if(mysqli_num_rows($sql_details) > 0)
    {
        $result_details = mysqli_fetch_assoc($sql_details);
    }

    $sql_checkfillform = mysqli_query($conn,"SELECT `std_enrollid` FROM `tbl_admission` WHERE `std_enrollid` = '{$user_id}'");
    if(mysqli_num_rows($sql_checkfillform) > 0)
    {
      echo "<script>window.location.replace(`edit.php`);</script>";
    }

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admission Form - APAS</title>

  <!-- Internal Css Files -->
  <link rel="stylesheet" href="assets/css/register-form.css">
  <link rel="stylesheet" href="assets/css/header.css" />
  <link rel="stylesheet" href="assets/css/dashboard.css">
  <link rel="stylesheet" href="assets/css/admissionform.css">



  <!-- Font-Awesome Icons -->
  <script src="https://kit.fontawesome.com/40963500f2.js" crossorigin="anonymous"></script>
</head>

<body>
  <header>
    <div class="mini-nav">
      <div class="left">
        <div class="phone">
          <i class="fa-solid fa-phone"></i>&nbsp;
          <a href="#">0161-9999000/001</a>
        </div>
        <div class="email">
          <i class="fa-solid fa-envelope"></i>&nbsp;
          <a href="#">demo-mail@mail.com</a>
        </div>
      </div>

      <div class="right">
        <div class="social">
          <a href="#"><i class="fa-brands fa-facebook"></i></a>
          <a href="#"><i class="fa-brands fa-twitter"></i></a>
          <a href="#"><i class="fa-brands fa-instagram"></i></a>
          <a href="#"><i class="fa-brands fa-linkedin"></i></a>
        </div>
      </div>
    </div>

    <nav>
      <div class="logo">
        <img src="assets/logo.png" alt="" />
        <div class="collage-name">
          <a href="#">
            <!-- <p class="head-small"></p> -->
            <p class="head-big">Admission Process Automation System</p>
          </a>
        </div>
      </div>
      <div class="nav">
      </div>
    </nav>
  </header>


  <div class="container">
    <section>
      <div class="welcome">
        <h2>Admission Form</h2>
        <p><span>Get Your Self Registered with APAS</span> <span>* Required</span></p>
      </div>

      <div class="register">
        <div class="form">

          <form action="" method="POST">
            <h1>Basic Details</h1>
            <div class="welcome">
        <p><span> </span> <span>Go Back to <a href="dashboard.php"><b>Dashboard</b></a>
           for any change in Basic Details</span></p>
      </div>
            <div class="input">
              <label for="name">Name <span class="required">*</span></label>
              <input type="text" name="name" id="name" value="<?php echo $result_details['std_name'];?>" placeholder="Enter Name" readonly>
            </div>

            <div class="input">
              <label for="age">Age <span class="required">*</span></label>
              <input type="text" name="age" id="age" placeholder="Enter Age" value="<?php

$from = date_create($result_details['std_dob']);
$to   = new DateTime('today');
echo $from->diff($to)->y;
?>" readonly>
            </div>

            <div class="input">
              <label for="gender">Gender <span class="required">*</span></label>
              <input type="radio" name="gender" value="M" <?php echo ($result_details['std_gender'] == "M") ? "checked" : "disabled";?>  readonly> Male
              <input type="radio" name="gender" value="F" <?php echo ($result_details['std_gender'] == "F") ? "checked" : "disabled";?> readonly> Female
              <input type="radio" name="gender" value="O" <?php echo ($result_details['std_gender'] == "O") ? "checked" : "disabled";?>  > Other
            </div>

            <div class="input">
              <label for="dob">Date of Birth <span class="required">*</span></label>
              <input type="date" name="dob" value="<?php echo $result_details['std_dob'];?>" readonly>
            </div>

            <div class="input">
              <label for="dob">Blood Group <span class="required">*</span></label>
              <select name="bloodgroup" id="bloodgroup" required>
                <option value="">Select</option>
                <option value="A+">A+</option>
                <option value="B+">B+</option>
                <option value="AB+">AB+</option>
                <option value="O+">O+</option>
                <option value="A-">A-</option>
                <option value="B-">B-</option>
                <option value="AB-">AB-</option>
                <option value="O-">O-</option>
              </select>
            </div>

            <div class="input">
              <label for="category">Category <span class="required">*</span></label>
              <select name="category" id="category" required>
                <option value="">Select</option>
                <option value="OBC">OBC</option>
                <option value="SC">SC</option>
                <option value="ST">ST</option>
                <option value="GEN">GEN</option>
              </select>
            </div>



            <div class="input">
              <label for="religion">Religion <span class="required">*</span></label>
              <input type="text" name="religion" id="religion" placeholder="Enter Religion" required>
            </div>

            <div class="input">
              <label for="martialstatus">Martial Status <span class="required">*</span></label>
              <input type="radio" name="martialstatus" value="1" required> Married
              <input type="radio" name="martialstatus" value="0" required> Unmarried

            </div>


            <h1>Contact Details</h1>

            <div class="input">
              <label for="semail">Email <span class="required">*</span></label>
              <input type="email" id="semail" name="semail" value="<?php echo $result_details['std_email'];?>" placeholder="Enter Email" readonly>
            </div>

            <div class="input">
              <label for="sphone">Phone <span class="required">*</span></label>
              <input type="tel" id="sphone" name="sphone" value="<?php echo $result_details['std_phone'];?>" placeholder="Enter Phone" pattern="[0-9]{10}" readonly>
            </div>

            <h1>Family Details</h1>
            <div class="input">
              <label for="fathername">Father's Name <span class="required">*</span></label>
              <input type="text" name="fathername" maxlength="50" id="fathername" placeholder="Enter Father's Name" required>
            </div>

            <div class="input">
              <label for="mothername">Mother's Name <span class="required">*</span></label>
              <input type="text" name="mothername" maxlength="50" id="mothername" placeholder="Enter Mother's Name" required>
            </div>

            <div class="input">
              <label for="email">Parent's Email <span class="required">*</span></label>
              <input type="email" id="email" name="email" placeholder="Enter Parent's Email" required>
            </div>

            <div class="input">
              <label for="phone">Parent's Phone <span class="required">*</span></label>
              <input type="tel" id="phone" name="phone" placeholder="Enter Parent's Phone"
                pattern="[0-9]{10}" required>
            </div>


            <h1>Address</h1>
            <div class="input">
              <label for="houseno">House Number <span class="required">*</span></label>
              <input type="text" name="houseno" id="houseno" placeholder="Enter House Number" required>
            </div>
            <div class="input">
              <label for="village">Village / Locality <span class="required">*</span></label>
              <input type="text" name="village" id="village" placeholder="Enter Village / Locality" required>
            </div>
            <div class="input">
              <label for="city">City <span class="required">*</span></label>
              <input type="text" name="city" id="city" placeholder="Enter City" required>
            </div>
            <div class="input">
              <label for="state">State <span class="required">*</span></label>
              <input type="text" name="state" id="state" placeholder="Enter State" required>
            </div>

            <div class="input">
              <label for="country">Country <span class="required">*</span></label>
              <input type="text" name="country" id="country" placeholder="Enter Country" required>
            </div>

            <div class="input">
              <label for="pincode">Pin Code <span class="required">*</span></label>
              <input type="text" name="pincode" id="pincode" placeholder="Enter Pin Code" required>
            </div>


            <h1>Identity Details</h1>
            <div class="input">
              <label for="aadharcard">Aadhar Card <span class="required">*</span></label>
              <input type="text" name="aadharcard" id="aadharcard" placeholder="Enter Aadhar Card" required>
            </div>

            <h1>Academic Qualification</h1>
            <div class="basicdetails">
              <div class="table"> 
                <table border="0" style="border:none;">
                  <tr>
                    <th width="15%">Exam Passed</th>
                    <th>Board</th>
                    <th width="18%">Year of Passing</th>
                    <th width="18%">Percentage (%)</th>
                  </tr>
                  <tr>
                    <td><label for="">10th <span class="required">*</span></td>
                    <td>
                      <div class="input">
                        <input type="text" name="tenthboard" id="tenthboard" placeholder="10th Board" required>
                      </div>
                    </td>
                    <td>
                      <div class="input">
                        <input type="text" name="tenthyop" id="tenthyop" placeholder="Year of Passing" required>
                      </div>
                    </td>
                    <td>
                      <div class="input">
                        <input type="text" name="tenthper" id="tenthper" placeholder="Percentage (%)" required>
                      </div>
                    </td>
                  </tr>

                  <tr>
                    <td><label for="">12th <span class="required">*</span></td>
                    <td>
                      <div class="input">
                        <input type="text" name="twelveboard" id="twelveboard" placeholder="12th Board" required>
                      </div>
                    </td>
                    <td>
                      <div class="input">
                        <input type="text" name="twelveyop" id="twelveyop" placeholder="Year of Passing" required>
                      </div>
                    </td>
                    <td>
                      <div class="input">
                        <input type="text" name="twelveper" id="twelveper" placeholder="Percentage (%)" required>
                      </div>
                    </td>
                  </tr>
                </table>
              </div>
            </div>

            <h1>PROGRAMME / COURSE INFORMATION</h1>
            <div class="welcome">
        <p><span> </span> <span><b>UG</b> - Under Graduate Courses | <b>PG</b> - Post Graduate Courses</span></p>
      </div>
          
            <div class="input">

              <label for="course">Course <span class="required">*</span></label>
              <select name="course" id="course" required>
                <option value="">Select</option>
                <?php
                    $sql_fetchcourse = mysqli_query($conn,"SELECT * FROM `tbl_course` ORDER BY `id` DESC");
                    if(mysqli_num_rows($sql_fetchcourse) > 0)
                    {
                        while($result_fetchcourse = mysqli_fetch_assoc($sql_fetchcourse)){
                          echo "<option value='".$result_fetchcourse['id']."'>";

                          echo ($result_fetchcourse['course'] == "ug") ? "UG" : "PG";
                          
                          echo " - ".$result_fetchcourse['stream']."</option>";
                        }
                    }
                ?>
                
              </select>

             

             
            </div>


            <div class="input">
              <input type="submit" name="applynow" value="Apply Now">
            </div>
          </form>
        </div>
      </div>
    </section>


  </div>



    <script src="assets/js/formvalidation.js"></script>

     <!-- For Email  -->

</body>

</html>


<?php
if(isset($_POST['applynow']))
{
  $bloodgroup = $_POST['bloodgroup'];
  $category = $_POST['category'];
  $religion = $_POST['religion'];
  $martialstatus = $_POST['martialstatus'];
  $fathername = $_POST['fathername'];
  $mothername = $_POST['mothername'];
  $parentemail = $_POST['email'];
  $parentphone = $_POST['phone'];
  $houseno = $_POST['houseno'];
  $village = $_POST['village'];
  $city = $_POST['city'];
  $state = $_POST['state'];
  $country = $_POST['country'];
  $pincode = $_POST['pincode'];
  $aadharcard = $_POST['aadharcard'];
  $tenthboard = $_POST['tenthboard'];
$tenthyop = $_POST['tenthyop'];
  $tenthper = $_POST['tenthper'];
  $twelveboard = $_POST['twelveboard'];
$twelveyop = $_POST['twelveyop'];
  $twelveper = $_POST['twelveper'];
  $courseid = $_POST['course'];

   // Set the new timezone
   date_default_timezone_set('Asia/Kolkata');
   $date = date('d-m-y h:i:s');

  $sql = mysqli_query($conn,"INSERT INTO `tbl_admission`(`datetime`, `std_enrollid`, `std_bloodgroup`, `std_category`, `std_religion`, `std_martialstatus`, `std_fathername`, `std_mothername`, `std_parentemail`, `std_parentphone`, `std_housenumber`, `std_village`, `std_city`, `std_state`, `std_country`, `std_pincode`, `std_aadharnumber`, `std_tenth_board`, `std_tenth_yop`, `std_tenth_per`, `std_twelve_board`, `std_twelve_yop`, `std_twelve_per`, `std_courseid`, `std_confirmed`) VALUES ('{$date}','{$user_id}','{$bloodgroup}','{$category}','{$religion}','$martialstatus','{$fathername}','{$mothername}','{$parentemail}','{$parentphone}','{$houseno}','{$village}','{$city}','{$state}','{$country}','$pincode','{$aadharcard}','{$tenthboard}','{$tenthyop}','{$tenthper}','{$twelveboard}','{$twelveyop}','{$twelveper}','{$courseid}','{0}')");
  if($sql){

    if($email_status == 0){
      echo "<script>alert('Done!!!');
    window.location.replace(`edit.php`);</script>";
    }else{
      echo '

      <script type="text/javascript"
      src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>
      
      <script>
    
      emailjs.init("JZXjyLlOrXEB1DddM");
  
      emailjs.send("service_pozrraa","template_8s7uztn",{
        subject: `Admission Form - APAS`,
        to: `'.$result_details["std_email"].'`,
        msg1: `Thanku '.$result_details["std_name"].' For Filling Admission Form !`,
        msg2: ``,
        msg3: `We have Received your Application at '.$date.' with Form No. '.$user_id.'`,
        msg4: `Please Upload Documents So that Your Application Get Reviewed...!`,
        msg5: ``,
        link: ``,
      }).then(() => {
        alert("Done!!! Check Your Inbox !");
              location.href="edit.php";
        },(err) => {
          alert("Done!!!");
            location.href="edit.php";
    });
  
      </script>';
    }
  }
}

?>