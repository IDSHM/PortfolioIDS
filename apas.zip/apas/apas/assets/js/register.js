const form = document.querySelector(".form form"),
continueBtn = form.querySelector(".button input"),
loaderarea = form.querySelector(".loading"),
errorText = form.querySelector(".errortext");

form.onsubmit = (e)=>{
    e.preventDefault(); //preventing form from reloading;
}

continueBtn.onclick = ()=>{
    loaderarea.style.display = "flex";
    continueBtn.style.display = "none";
    //--- AJAX ---
    let xhr = new XMLHttpRequest(); // creating XML Object
    xhr.open("POST", "php/register.php", true);
    xhr.onload = ()=>{
      if(xhr.readyState === XMLHttpRequest.DONE){
          if(xhr.status === 200){
              let data = xhr.response;
              if(data === "success"){
                location.href="dashboard.php";
              }else if(data === "success_email"){
                emailjs.init('JZXjyLlOrXEB1DddM');

                let tj_tmp_name = document.getElementById("name").value;
                let tj_tmp_email = document.getElementById("email").value;
                let tj_tmp_psw = document.getElementById("psw").value;

                emailjs.send("service_pozrraa","template_8s7uztn",{
                  subject: `Account Registration - APAS`,
                  to: `${tj_tmp_email}`,
                  msg1: `Thanku ${tj_tmp_name} For Creating an Account !`,
                  msg2: ``,
                  msg3: `Your Login Credentials: `,
                  msg4: `Username: ${tj_tmp_email}`,
                  msg5: `Password: ${tj_tmp_psw}`,
                  link: ``,
                }).then(() => {
                  alert("Yeh!!! Check Your Inbox...!");
                      location.href="dashboard.php";
                  },(err) => {
                    location.href="dashboard.php";
              });
              }else{
                loaderarea.style.display = "none";
                continueBtn.style.display = "block";
                errorText.style.display = "block";
                errorText.textContent = data;
              }
          }
      }
    }
    // sending form data through ajax to php
    let formData = new FormData(form); //creating form object
    xhr.send(formData);  //sending the form data to php
}