<?php 
    session_start();
    include_once "php/connection.php";

    if(!isset($_SESSION['std_enrollid'])){
      echo '
      <script>window.location.replace("./login.php")</script>;
      ';
     }
  //  error_reporting(0);

   $user_id = $_SESSION['std_enrollid'];

   $sql_details = mysqli_query($conn,"SELECT `std_enrollid`, `std_datetime`, `std_name`, `std_gender`, `std_dob`, `std_email`, `std_phone` FROM `tbl_account` WHERE `std_enrollid` =  '{$user_id}'");
    if(mysqli_num_rows($sql_details) > 0)
    {
        $result_details = mysqli_fetch_assoc($sql_details);
    }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Change Password - APAS</title>

    <!-- Internal Css Files -->
    <link rel="stylesheet" href="assets/css/header.css" />
    <link rel="stylesheet" href="assets/css/register-form.css">

    <!-- Font-Awesome Icons -->
    <script
      src="https://kit.fontawesome.com/40963500f2.js"
      crossorigin="anonymous"
    ></script>
  </head>
  <body>
    <header>
      <div class="mini-nav">
        <div class="left">
          <div class="phone">
            <i class="fa-solid fa-phone"></i>&nbsp;
            <a href="#">0161-9999000/001</a>
          </div>
          <div class="email">
            <i class="fa-solid fa-envelope"></i>&nbsp;
            <a href="#">demo-mail@mail.com</a>
          </div>
        </div>

        <div class="right">
          <div class="social">
              <a href="#"><i class="fa-brands fa-facebook"></i></a>
              <a href="#"><i class="fa-brands fa-twitter"></i></a>
              <a href="#"><i class="fa-brands fa-instagram"></i></a>
              <a href="#"><i class="fa-brands fa-linkedin"></i></a>
          </div>
        </div>
      </div>

      <nav>
        <div class="logo">
          <img src="assets/logo.png" alt="" />
          <div class="collage-name">
            <a href="#">
                <!-- <p class="head-small"></p> -->
                <p class="head-big">Admission Process Automation System</p>
            </a>
          </div>
        </div>
        <div class="nav">
        <a href="./dashboard.php" class="login-btn">Dashboard</a>
        </div>
      </nav>
    </header>


    <section>
        <div class="register">
            <h6>Change Password</h6>
            <div class="info">
                <p> </p>

                <p class="required">* Required</p>
            </div>

            <div class="form">
                <form action="" method="POST">

                <div class="input">
                        <label for="email">Email <span class="required">*</span></label>
                        <input type="email" id="email" name="email" readonly value="<?php echo $result_details['std_email'];?>" placeholder="Enter Email" required>
                    </div>

                    <div class="input">
                        <label for="phone">Phone <span class="required">*</span></label>
                        <input type="tel" readonly value="<?php echo $result_details['std_phone'];?>" id="phone" name="phone" placeholder="Enter Phone"  pattern="[0-9]{10}" required>
                    </div>
                    
                <div class="input">
                        <label for="psw">New Password <span class="required">*</span></label>
                        <input type="password" maxlength="16" name="psw" id="psw" placeholder="Enter Password"  required>
                        <div class="infopsw">
                          <div class="showpsw">
                            <input type="checkbox" name="showpsw" id="showpsw"><span class="show-password" value="1">Show Password</span>
                          </div>
                          <div id="alertpsw">
                          </div>
                        </div>
                    </div>

                    <div class="input button">
                        <input type="submit" name="updatepsw" value="Update">
                    </div>

                </form>
            </div>
        </div>
    </section>


    <script src="assets/js/showpassword.js"></script>
    <script src="assets/js/formvalidation.js"></script>
  </body>
</html>


<?php

if(isset($_POST['updatepsw']))
{
    $psw = $_POST['psw'];

  $sql_updatepsw = "UPDATE `tbl_account` SET `std_psw`='{$psw}'";
if(mysqli_query($conn,$sql_updatepsw)){
  echo '<script>
  alert("Password Updated Successfully !");
  window.location.replace("dashboard.php");</script>'; 
}
}
?>