<?php 
    session_start();
    include_once "php/connection.php";
  //  error_reporting(0);

  if(!isset($_SESSION['std_enrollid'])){
    echo '
    <script>window.location.replace("./login.php")</script>;
    ';
   }

   $user_id = $_SESSION['std_enrollid'];

   $sql_details = mysqli_query($conn,"SELECT `std_enrollid`, `std_datetime`, `std_name`, `std_gender`, `std_dob`, `std_email`, `std_phone` FROM `tbl_account` WHERE `std_enrollid` =  '{$user_id}'");
    if(mysqli_num_rows($sql_details) > 0)
    {
        $result_details = mysqli_fetch_assoc($sql_details);
    }

    $sql_status = mysqli_query($conn,"SELECT * FROM `tbl_status` WHERE `std_enrollid` =  '{$user_id}'");
    if(mysqli_num_rows($sql_status) > 0)
    {
        $result_status = mysqli_fetch_assoc($sql_status);
    }

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Cache Memory -->
    <meta http-equiv='cache-control' content='no-cache'>
<meta http-equiv='expires' content='0'>
<meta http-equiv='pragma' content='no-cache'>


    <title>User Dashboard - APAS</title>

    <!-- Internal Css Files -->
    <link rel="stylesheet" href="assets/css/header.css" />
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <link rel="stylesheet" href="assets/css/notify.css">

    <!-- Font-Awesome Icons -->
    <script
      src="https://kit.fontawesome.com/40963500f2.js"
      crossorigin="anonymous"
    ></script>
  </head>
  <body>
    <header>
      <div class="mini-nav">
        <div class="left">
          <div class="phone">
            <i class="fa-solid fa-phone"></i>&nbsp;
            <a href="#">0161-9999000/001</a>
          </div>
          <div class="email">
            <i class="fa-solid fa-envelope"></i>&nbsp;
            <a href="#">demo-mail@mail.com</a>
          </div>
        </div>

        <div class="right">
          <div class="social">
              <a href="#"><i class="fa-brands fa-facebook"></i></a>
              <a href="#"><i class="fa-brands fa-twitter"></i></a>
              <a href="#"><i class="fa-brands fa-instagram"></i></a>
              <a href="#"><i class="fa-brands fa-linkedin"></i></a>
          </div>
        </div>
      </div>

      <nav>
        <div class="logo">
          <img src="assets/logo.png" alt="" />
          <div class="collage-name">
            <a href="#">
                <!-- <p class="head-small"></p> -->
                <p class="head-big">Admission Process Automation System</p>
            </a>
          </div>
        </div>
        <div class="nav">
          <a href="changepassword.php">Change Password</a>
          <a href="php/logout.php" class="login-btn">Log Out</a>
        </div>
      </nav>
    </header>


    <div class="container">
        <section>
            <div class="welcome">
                <h2>Welcome <?php echo $result_details['std_name'];?> !</h2>
                <p>Get Your Self Registered with APAS</p>
            </div>
        </section>

        

        <section>
            <div class="basicdetails">
                <h2>Basic Details</h2>
                <div class="table">
                    <table border="0">
                        <tr>
                            <th>Name</th>
                            <td><?php echo $result_details['std_name'];?></td>
                            <?php
                    if($result_status['std_profilepic'] == 1)
                    {
                      
                      echo '<td rowspan="6" width="186px">
                      <img src="documents/photo/'.$user_id.'.jpg" width="100%" height="100%" alt="">
                  </td>';
                    }
                    ?>
                        </tr>
                        <tr>
                            <th>Age</th>
                            <td>
                              <?php
                                # object oriented
$from = date_create($result_details['std_dob']);
$to   = new DateTime('today');
echo $from->diff($to)->y;
                              ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Gender</th>
                            <td><?php echo ($result_details['std_gender'] == "M") ? "Male" : "Female";?></td>
                        </tr>
                        <tr>
                            <th>DOB</th>
                            <td>
                              <?php 
                              $date=date_create($result_details['std_dob']);
                              echo date_format($date,"d / M / Y");
                            ?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td><?php echo $result_details['std_email'];?></td>
                        </tr>
                        <tr>
                            <th>Phone</th>
                            <td><?php echo $result_details['std_phone'];?></td>
                        </tr>
                    </table>
                </div>
                <div class="buttons">
                <?php
                    if($result_status['std_admissionform'] == 0)
                    {
                    echo '<button onclick="window.location.replace(`editbasicdetails.php`);" style="background-color: #f03c02;">Edit Details</button>';
                    }

                    if($result_status['std_profilepic'] == 1 && $result_status['std_admissionform'] == 0)
                    {
                      echo "<form action='' method='POST'><button type='submit' value='updateprofile' name='updateimage'>Update Image</button></form>";
                    }

                    
          if(isset($_POST['updateimage']))
          {        
          $sql_profiepicupload = "UPDATE `tbl_status` SET `std_profilepic`='0' WHERE `std_enrollid` = {$user_id}";
          if(mysqli_query($conn,$sql_profiepicupload)){
            echo '<script>window.location.replace("dashboard.php");</script>'; 
          }
          }
                    ?>
                </div>
            </div>
        </section>


        <?php
          if($result_status['std_profilepic'] != 1)
          {
            echo '<section>
            <div class="welcome">
                    <h2>Important Instructions</h2>
                    <p >
                      <ul style="margin:0px 20px;">
                        <li style="margin:5px 0px;">Upload Profile Picture to Fill Admission Form.</li>
                        <li style="margin:5px 0px;">Your Profile Picture will use for further process so please upload a formal passport size picture.</li>
                        <li style="margin:5px 0px;"><b>Max File Size 100KB.</b></li>
                      </ul>
                    </p>
                </div>
            </section>
            
            <section>
            <div class="upprofilepic">
                <h2>Upload Profile Picture</h2>
                <div class="upprofilepicform">
                    <center>
                        <img id="outputupprofilepic" src="" alt="">
                    </center>
                    
                    <form action="" method="POST"  enctype="multipart/form-data">
                        <input type="file" accept="image/*" name="profileimage" onchange="loadFilep(event)" required>
                        <button type="submit" value="Upload" name="submitpic">Upload</button>
                    </form>
                </div>
            </div>
        </section>';
          }

          if(isset($_POST['submitpic']))
{
  
  $filename = $user_id;
  $filename .= ".jpg";
  $tempname = $_FILES["profileimage"]["tmp_name"];
$folder = "documents/photo/".$filename;
move_uploaded_file($tempname,$folder);


$file_size = $_FILES["profileimage"]['size'];

if (($file_size > 150000)){      
    echo '<script type="text/javascript">alert("File too large. File must be less than 100KB.");</script>'; 
}else{
  $sql_profiepicupload = "UPDATE `tbl_status` SET `std_profilepic`='1' WHERE `std_enrollid` = {$user_id}";
if(mysqli_query($conn,$sql_profiepicupload)){
  echo '<script>
  alert("Profile Pic Uploaded !");
  window.location.replace("dashboard.php");</script>'; 
}
}
}
          ?>



<?php
          if($result_status['std_profilepic'] == 1)
          {

            // Admission Form Notice
            if($result_status['std_admissionform'] == 0){
              echo '<section>
              <div class="welcome">
                      <h2>Important Instructions</h2>
                      <p >
                        <ul style="margin:0px 20px;">
                          <li style="margin:5px 0px;">Please Fill the Admission Form For Further Process.</li>
                          <li style="margin:5px 0px;"><b>Your Basic Details and Profile Picture will use For Further Process.</b></li>
                          <li style="margin:5px 0px;"><b>After Filling Admission Form you were not allow to Update your Basic Details and Profile Picture.</b></li>
                        </ul>
                      </p>
                  </div>
              </section>';
            }

            // Document uplaod Notice
            if($result_status['std_documentupload'] == 0 && $result_status['std_admissionform'] == 1){
              echo '<section>
              <div class="welcome">
                      <h2>Important Instructions</h2>
                      <p >
                        <ul style="margin:0px 20px;">
                          <li style="margin:5px 0px;"><b>Please Upload Documents For Further Process.</b></li>
                        </ul>
                      </p>
                  </div>
              </section>';
            }

            echo '
            <section>
            <div class="admform">
                <h2>Admission Form</h2>
                <!--<p>Last Date to Fill Form and Upload Document : 31/Dec/2021</p>-->
                <div>
                    <span>Fill Admission Form</span>';
                    
                    // Admission form button
            if($result_status['std_admissionform'] == 0){
              echo '<button onclick="window.location.replace(`admissionform.php`)">Fill Form</button>';
            }else{
              echo '<button style="background:green;color:white;">Done</button>';
            }

            echo '</div>';

           
              // upload documents button
              if($result_status['std_admissionform'] == 1){
                echo '<div>
                <span>Upload Documents</span>';
                
                if($result_status['std_documentupload'] == 0){
                  echo '<button onclick="window.location.replace(`uploaddocuments.php`)">Upload</button>';
                }else{
                  echo '<button style="background:green;color:white;">Done</button>';
                }
                

                echo '
            </div>';
              }  
              
            echo '</div>
        </section>';
          }
          ?>

<?php
          if($result_status['std_documentupload'] == 1)
          {
            echo '  <section>
            <div class="admform">
                <h2>Application Status</h2>
                <div>
                    <span>View Form</span>
                    <button onclick="window.location.replace(`userviewform.php`);">View</button>
                </div>';

                if($result_status['std_review'] == 0){
                  echo '<div>
                  <span>Review</span>
                  <button>Pending</button>
              </div>';
                }else if($result_status['std_review'] == -1){
                  echo '<div>
                  <span>Review</span>
                  <span>Reason: '.$result_status['std_rejectionmsg'].'</span>
                  <button style="background:red">Rejected</button>
              </div>';
                }else if($result_status['std_review'] == 1){
                  echo '<div>
                  <span>Review</span>
                  <button style="background:green">Done</button>
              </div>';

              if($result_status['std_interview'] == 0){
                echo '
                <div>
                <span>Interview</span>
                <button>Pending</button>
            </div>
                ';
              }else if($result_status['std_interview'] == 1 && $result_status['std_approval'] == 0){
                echo '<div>
                <span>Interview</span>
                <span>DateTime: ';
                
                $tjdate=date_create($result_status['interview_datetime']);
               echo date_format($tjdate,"d-M-Y h:i A");
                
                echo '</span>
                <a href="'.$result_status['interview_link'].'" target="_blank"><button>Join</button></a>
            </div>';
              }else if($result_status['std_review'] == 1){

                echo '<div>
                <span>Interview</span>
  
                <button style="background:green">Done</button>
            </div>';

            if($result_status['std_approval'] == 1){
              echo '<div>
                <span>Application</span>
                <span>Go to View Form and Download the Application.	</span>
                <button style="background:green">Approved</button>
            </div>';
            }else if($result_status['std_approval'] == -1){
              echo '<div>
                <span>Application</span>
                <span>Reason: '.$result_status['std_rejectionmsg'].'</span>
                <button style="background:red">Rejected</button>
            </div>';
            }
            
                }


                echo '
            </div>
        </section>
      </div>';
          }
        }
          ?>




          <!-- <div class="notification  success">
            <div class="content">
              <p>Image Uploaded Succesfully !</p>
            </div>
            <div class="cross">
            <i class="fa-solid fa-xmark"></i>
            </div>
          </div> -->

          

        

      

    <script>
         var loadFilep = function(event) {       
          var output = document.getElementById('outputupprofilepic');
        
        output.src = URL.createObjectURL(event.target.files[0]);
        output.style.width = "194px";
        ouput.style.height = "200px";
        output.onload = function() {
          URL.revokeObjectURL(output.src) // free memory
        }
      };
    </script>
</body>
</html>