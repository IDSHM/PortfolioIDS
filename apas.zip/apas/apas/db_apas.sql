-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 16, 2022 at 07:42 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_apas`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_account`
--

CREATE TABLE `tbl_account` (
  `std_enrollid` int(11) NOT NULL,
  `std_datetime` varchar(20) NOT NULL,
  `std_name` varchar(50) NOT NULL,
  `std_gender` varchar(2) NOT NULL,
  `std_dob` varchar(15) NOT NULL,
  `std_email` varchar(50) NOT NULL,
  `std_phone` varchar(15) NOT NULL,
  `std_psw` varchar(17) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_account`
--

INSERT INTO `tbl_account` (`std_enrollid`, `std_datetime`, `std_name`, `std_gender`, `std_dob`, `std_email`, `std_phone`, `std_psw`) VALUES
(2, '06-11-22 12:35:29', 'Sukhjinder Singh', 'M', '2007-02-12', 'sukhjindergahir12@gmail.com', '9256420532', '123'),
(3, '06-11-22 01:51:32', 'Keshav Kumar', 'M', '2000-04-09', 'keshav3575@gmail.com', '8968962432', '123'),
(4, '06-11-22 01:56:16', 'Ravi Sharma', 'M', '2003-10-05', '9876ravisharma@gmail.com', '9879879870', '123'),
(5, '06-11-22 02:06:31', 'Gourav Arora', 'M', '2001-06-20', 'gouravpctebtech19cse@gmail.com', '9876598765', '123'),
(6, '06-11-22 02:19:13', 'Tejinder Singh', 'M', '2001-04-19', 'tejinderpctebtech19cse@gmail.com', '8427045166', '123'),
(13, '17-11-22 12:00:40', 'Tejinder Singh', 'M', '2001-04-19', 'tejindergahir19@gmail.com', '8427945166', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admission`
--

CREATE TABLE `tbl_admission` (
  `datetime` varchar(20) NOT NULL,
  `std_enrollid` int(11) NOT NULL,
  `std_bloodgroup` varchar(3) NOT NULL,
  `std_category` varchar(5) NOT NULL,
  `std_religion` varchar(15) NOT NULL,
  `std_martialstatus` int(11) NOT NULL,
  `std_fathername` varchar(50) NOT NULL,
  `std_mothername` varchar(50) NOT NULL,
  `std_parentemail` varchar(50) NOT NULL,
  `std_parentphone` varchar(15) NOT NULL,
  `std_housenumber` varchar(10) NOT NULL,
  `std_village` varchar(16) NOT NULL,
  `std_city` varchar(16) NOT NULL,
  `std_state` varchar(16) NOT NULL,
  `std_country` varchar(16) NOT NULL,
  `std_pincode` int(11) NOT NULL,
  `std_aadharnumber` varchar(16) NOT NULL,
  `std_tenth_board` varchar(50) NOT NULL,
  `std_tenth_yop` int(11) NOT NULL,
  `std_tenth_per` float NOT NULL,
  `std_twelve_board` varchar(50) NOT NULL,
  `std_twelve_yop` int(11) NOT NULL,
  `std_twelve_per` float NOT NULL,
  `std_courseid` int(11) NOT NULL,
  `std_confirmed` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_admission`
--

INSERT INTO `tbl_admission` (`datetime`, `std_enrollid`, `std_bloodgroup`, `std_category`, `std_religion`, `std_martialstatus`, `std_fathername`, `std_mothername`, `std_parentemail`, `std_parentphone`, `std_housenumber`, `std_village`, `std_city`, `std_state`, `std_country`, `std_pincode`, `std_aadharnumber`, `std_tenth_board`, `std_tenth_yop`, `std_tenth_per`, `std_twelve_board`, `std_twelve_yop`, `std_twelve_per`, `std_courseid`, `std_confirmed`) VALUES
('06-11-22 01:48:17', 2, 'B-', 'GEN', 'Sikh', 0, 'Gurdeep Singh', 'Rupinder Kaur', 'gdeepgahir@gmail.com', '9872619209', '891', 'Dhandari Kalan ', 'Ludhiana', 'Punjab', 'India', 141003, '914438717848', 'Punjab School Education Board', 2022, 90, 'Punjab School Education Board', 2024, 85, 1, 1),
('06-11-22 01:53:21', 3, 'O+', 'GEN', 'Hindu', 0, 'Rajnik Kumar', 'Mother Name', 'keshav3575@gmail.com', '8968962432', 'Shimla Pur', 'Shimla Puri', 'Ludhiana', 'Punjab', 'India', 141003, '123412341234', 'Punjab School Education Board', 2016, 80, 'Punjab School Education Board', 2018, 80, 1, 1),
('06-11-22 02:04:19', 4, 'O+', 'OBC', 'Hindu', 0, 'Ravi Sharma', 'Ravi Sharma', '9876ravisharma@gmail.com', '9879879870', 'Focal Poin', 'Focal Point', 'Ludhiana', 'Punjab', 'India', 141010, '123456123456', 'Punjab School Education Board', 2017, 80, 'Punjab School Education Board', 2019, 80, 2, 1),
('06-11-22 02:12:36', 5, 'O+', 'GEN', 'Hindu', 0, 'Gourav Arora', 'Gourav Arora', 'gouravpctebtech19cse@gmail.com', '9876598765', 'Gandhi Nag', 'Gandhi Nagar', 'Ludhiana', 'Punjab', 'India', 141010, '123457123457', 'Punjab School Education Board', 2017, 70, 'Punjab School Education Board', 2019, 70, 2, 1),
('06-11-22 03:35:03', 6, 'A-', 'GEN', 'Sikh', 0, 'Gurdeep Singh', 'Rupinder Kaur', 'gdeepgahir@gmail.com', '9872619209', '891', 'Dhandari Kalan', 'Ludhiana', 'Punjab', 'India', 141003, '914438717848', 'Central Board of Secondary Education', 2017, 92.6, 'Central Board of Secondary Education ', 2019, 76.6, 2, 1),
('17-11-22 12:02:16', 13, 'A-', 'OBC', 'Sikh', 0, 'Gurdeep Singh', 'Rupinder Kaur', 'gdeepgahir@gmail.com', '9872619209', '891', 'Dhandari Kalan', 'Ludhiana', 'Punjab', 'India', 141010, '914438717848', 'Central Board of Secondary Education', 2017, 92.6, 'Central Board of Secondary Education ', 2019, 76.6, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course`
--

CREATE TABLE `tbl_course` (
  `id` int(11) NOT NULL,
  `course` varchar(3) NOT NULL,
  `stream` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_course`
--

INSERT INTO `tbl_course` (`id`, `course`, `stream`) VALUES
(1, 'ug', 'Computer Science and Engineering'),
(2, 'ug', 'Mechanical Engineering');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_status`
--

CREATE TABLE `tbl_status` (
  `std_enrollid` int(11) NOT NULL,
  `std_profilepic` int(11) NOT NULL,
  `std_admissionform` int(11) NOT NULL,
  `std_documentupload` int(11) NOT NULL,
  `std_review` int(11) NOT NULL,
  `std_interview` int(11) NOT NULL,
  `std_approval` int(11) NOT NULL,
  `std_rejectionmsg` varchar(500) NOT NULL,
  `interview_link` varchar(100) NOT NULL,
  `interview_datetime` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_status`
--

INSERT INTO `tbl_status` (`std_enrollid`, `std_profilepic`, `std_admissionform`, `std_documentupload`, `std_review`, `std_interview`, `std_approval`, `std_rejectionmsg`, `interview_link`, `interview_datetime`) VALUES
(2, 1, 1, 1, 1, 1, 0, '', 'https://meet.google.com/owc-jspq-rtc', '2022-11-17T12:40'),
(3, 1, 1, 1, 1, 0, 0, '', '', ''),
(4, 1, 1, 1, 1, 0, 0, '', '', ''),
(5, 1, 1, 1, 0, 0, 0, '', '', ''),
(6, 1, 1, 1, -1, 0, 0, 'Incorrect Information...!', '', ''),
(13, 1, 1, 1, 1, 1, 1, 'Behaviour Not Good !', 'https://google.meet.com', '2022-11-18T13:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_account`
--
ALTER TABLE `tbl_account`
  ADD PRIMARY KEY (`std_enrollid`);

--
-- Indexes for table `tbl_admission`
--
ALTER TABLE `tbl_admission`
  ADD PRIMARY KEY (`std_enrollid`);

--
-- Indexes for table `tbl_course`
--
ALTER TABLE `tbl_course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_status`
--
ALTER TABLE `tbl_status`
  ADD PRIMARY KEY (`std_enrollid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_account`
--
ALTER TABLE `tbl_account`
  MODIFY `std_enrollid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_course`
--
ALTER TABLE `tbl_course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
