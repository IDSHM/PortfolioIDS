<?php 
    session_start();
    include_once "php/connection.php";
  //  error_reporting(0);

  if(!isset($_SESSION['std_enrollid'])){
    echo '
    <script>window.location.replace("./login.php")</script>;
    ';
   }

   $user_id = $_SESSION['std_enrollid'];



   $sql_details = mysqli_query($conn,"SELECT `std_enrollid`, `std_datetime`, `std_name`, `std_gender`, `std_dob`, `std_email`, `std_phone` FROM `tbl_account` WHERE `std_enrollid` =  '{$user_id}'");
    if(mysqli_num_rows($sql_details) > 0)
    {
        $result_details = mysqli_fetch_assoc($sql_details);
    }

    $sql_formdetails = mysqli_query($conn,"SELECT * FROM `tbl_admission` WHERE `std_enrollid` =  '{$user_id}'");
    if(mysqli_num_rows($sql_formdetails) > 0)
    {
      $result_formdetails = mysqli_fetch_assoc($sql_formdetails);
    }

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Edit Admission Form - APAS</title>

  <!-- Internal Css Files -->
  <link rel="stylesheet" href="assets/css/register-form.css">
  <link rel="stylesheet" href="assets/css/header.css" />
  <link rel="stylesheet" href="assets/css/dashboard.css">
  <link rel="stylesheet" href="assets/css/admissionform.css">



  <!-- Font-Awesome Icons -->
  <script src="https://kit.fontawesome.com/40963500f2.js" crossorigin="anonymous"></script>
</head>

<body>
  <header>
    <div class="mini-nav">
      <div class="left">
        <div class="phone">
          <i class="fa-solid fa-phone"></i>&nbsp;
          <a href="#">0161-9999000/001</a>
        </div>
        <div class="email">
          <i class="fa-solid fa-envelope"></i>&nbsp;
          <a href="#">demo-mail@mail.com</a>
        </div>
      </div>

      <div class="right">
        <div class="social">
          <a href="#"><i class="fa-brands fa-facebook"></i></a>
          <a href="#"><i class="fa-brands fa-twitter"></i></a>
          <a href="#"><i class="fa-brands fa-instagram"></i></a>
          <a href="#"><i class="fa-brands fa-linkedin"></i></a>
        </div>
      </div>
    </div>

    <nav>
      <div class="logo">
        <img src="assets/logo.png" alt="" />
        <div class="collage-name">
          <a href="#">
            <!-- <p class="head-small"></p> -->
            <p class="head-big">Admission Process Automation System</p>
          </a>
        </div>
      </div>
      <div class="nav">

      </div>
    </nav>
  </header>


  <div class="container">
    <section>
      <div class="welcome">
        <h2>Edit Admission Form</h2>
        <p><span>Get Your Self Registered with APAS</span> <span>* Required</span></p>
      </div>

      <div class="register">
        <div class="form">

          <form action="" method="POST">
            <h1>Basic Details</h1>
            <div class="welcome">
        <p><span> </span> <span>Go Back to <a href="dashboard.php"><b>Dashboard</b></a>
           for any change in Basic Details</span></p>
      </div>
            <div class="input">
              <label for="name">Name <span class="required">*</span></label>
              <input type="text" name="name" id="name" value="<?php echo $result_details['std_name'];?>" placeholder="Enter Name" readonly>
            </div>

            <div class="input">
              <label for="age">Age <span class="required">*</span></label>
              <input type="text" name="age" id="age" placeholder="Enter Age" value="<?php

$from = date_create($result_details['std_dob']);
$to   = new DateTime('today');
echo $from->diff($to)->y;
?>" readonly>
            </div>

            <div class="input">
              <label for="gender">Gender <span class="required">*</span></label>
              <input type="radio" name="gender" value="M" <?php echo ($result_details['std_gender'] == "M") ? "checked" : "disabled";?>  readonly> Male
              <input type="radio" name="gender" value="F" <?php echo ($result_details['std_gender'] == "F") ? "checked" : "disabled";?> readonly> Female
              <input type="radio" name="gender" value="O" <?php echo ($result_details['std_gender'] == "O") ? "checked" : "disabled";?>  > Other
            </div>

            <div class="input">
              <label for="dob">Date of Birth <span class="required">*</span></label>
              <input type="date" name="dob" value="<?php echo $result_details['std_dob'];?>" readonly>
            </div>

            <div class="input">
              <label for="dob">Blood Group <span class="required">*</span></label>
              <select name="bloodgroup" id="bloodgroup" required>
                <option value="">Select</option>
                <option value="A+" <?php echo ($result_formdetails['std_bloodgroup'] == "A+") ? "selected": ""; ?> >A+</option>
                <option value="B+" <?php echo ($result_formdetails['std_bloodgroup'] == "B+") ? "selected": ""; ?>>B+</option>
                <option value="AB+" <?php echo ($result_formdetails['std_bloodgroup'] == "AB+") ? "selected": ""; ?>>AB+</option>
                <option value="O+" <?php echo ($result_formdetails['std_bloodgroup'] == "O+") ? "selected": ""; ?>>O+</option>
                <option value="A-" <?php echo ($result_formdetails['std_bloodgroup'] == "A-") ? "selected": ""; ?>>A-</option>
                <option value="B-" <?php echo ($result_formdetails['std_bloodgroup'] == "B-") ? "selected": ""; ?>>B-</option>
                <option value="AB-" <?php echo ($result_formdetails['std_bloodgroup'] == "AB-") ? "selected": ""; ?>>AB-</option>
                <option value="O-" <?php echo ($result_formdetails['std_bloodgroup'] == "O-") ? "selected": ""; ?>>O-</option>
              </select>
            </div>

            <div class="input">
              <label for="category">Category <span class="required">*</span></label>
              <select name="category" id="category" required>
                <option value="">Select</option>
                <option value="OBC" <?php echo ($result_formdetails['std_category'] == "OBC") ? "selected": ""; ?>>OBC</option>
                <option value="SC" <?php echo ($result_formdetails['std_category'] == "SC") ? "selected": ""; ?>>SC</option>
                <option value="ST" <?php echo ($result_formdetails['std_category'] == "ST") ? "selected": ""; ?>>ST</option>
                <option value="GEN" <?php echo ($result_formdetails['std_category'] == "GEN") ? "selected": ""; ?>>GEN</option>
              </select>
            </div>



            <div class="input">
              <label for="religion">Religion <span class="required">*</span></label>
              <input type="text" name="religion" id="religion" placeholder="Enter Religion" value="<?php echo $result_formdetails['std_religion'];?>" required>
            </div>

            <div class="input">
              <label for="martialstatus">Martial Status <span class="required">*</span></label>
              <input type="radio" <?php echo ($result_formdetails['std_martialstatus'] == 1) ? "checked": ""; ?> name="martialstatus" value="1" required> Married
              <input type="radio"  <?php echo ($result_formdetails['std_martialstatus'] == 0) ? "checked": ""; ?> name="martialstatus" value="0" required> Unmarried

            </div>


            <h1>Contact Details</h1>

            <div class="input">
              <label for="semail">Email <span class="required">*</span></label>
              <input type="email" id="semail" name="semail" value="<?php echo $result_details['std_email'];?>" placeholder="Enter Email" readonly>
            </div>

            <div class="input">
              <label for="sphone">Phone <span class="required">*</span></label>
              <input type="tel" id="sphone" name="sphone" value="<?php echo $result_details['std_phone'];?>" placeholder="Enter Phone" pattern="[0-9]{10}" readonly>
            </div>

            <h1>Family Details</h1>
            <div class="input">
              <label for="fathername">Father's Name <span class="required">*</span></label>
              <input type="text" name="fathername" maxlength="50" id="fathername" value="<?php echo $result_formdetails['std_fathername'];?>" placeholder="Enter Father's Name" required>
            </div>

            <div class="input">
              <label for="mothername">Mother's Name <span class="required">*</span></label>
              <input type="text" name="mothername" maxlength="50" id="mothername" value="<?php echo $result_formdetails['std_mothername'];?>" placeholder="Enter Mother's Name" required>
            </div>

            <div class="input">
              <label for="email">Parent's Email <span class="required">*</span></label>
              <input type="email" value="<?php echo $result_formdetails['std_parentemail'];?>" id="email" name="email" placeholder="Enter Parent's Email" required>
            </div>

            <div class="input">
              <label for="phone">Parent's Phone <span class="required">*</span></label>
              <input type="tel" value="<?php echo $result_formdetails['std_parentphone'];?>" id="phone" name="phone" placeholder="Enter Parent's Phone"
                pattern="[0-9]{10}" required>
            </div>


            <h1>Address</h1>
            <div class="input">
              <label for="houseno">House Number <span class="required">*</span></label>
              <input type="text" name="houseno" id="houseno" placeholder="Enter House Number" value="<?php echo $result_formdetails['std_housenumber'];?>" required>
            </div>
            <div class="input">
              <label for="village">Village / Locality <span class="required">*</span></label>
              <input type="text" name="village" id="village" placeholder="Enter Village / Locality" value="<?php echo $result_formdetails['std_village'];?>" required>
            </div>
            <div class="input">
              <label for="city">City <span class="required">*</span></label>
              <input type="text" name="city" id="city" placeholder="Enter City" value="<?php echo $result_formdetails['std_city'];?>" required>
            </div>
            <div class="input">
              <label for="state">State <span class="required">*</span></label>
              <input type="text" name="state" id="state" placeholder="Enter State" value="<?php echo $result_formdetails['std_state'];?>" required>
            </div>

            <div class="input">
              <label for="country">Country <span class="required">*</span></label>
              <input type="text" name="country" id="country" placeholder="Enter Country" value="<?php echo $result_formdetails['std_country'];?>" required>
            </div>

            <div class="input">
              <label for="pincode">Pin Code <span class="required">*</span></label>
              <input type="text" name="pincode" id="pincode" placeholder="Enter Pin Code" value="<?php echo $result_formdetails['std_pincode'];?>" required>
            </div>


            <h1>Identity Details</h1>
            <div class="input">
              <label for="aadharcard">Aadhar Card <span class="required">*</span></label>
              <input type="text" name="aadharcard" id="aadharcard" placeholder="Enter Aadhar Card" value="<?php echo $result_formdetails['std_aadharnumber'];?>" required>
            </div>

            <h1>Academic Qualification</h1>
            <div class="basicdetails">
              <div class="table"> 
                <table border="0" style="border:none;">
                  <tr>
                    <th width="15%">Exam Passed</th>
                    <th>Board</th>
                    <th width="18%">Year of Passing</th>
                    <th width="18%">Percentage (%)</th>
                  </tr>
                  <tr>
                    <td><label for="">10th <span class="required">*</span></td>
                    <td>
                      <div class="input">
                        <input type="text" name="tenthboard" id="tenthboard" value="<?php echo $result_formdetails['std_tenth_board'];?>" placeholder="10th Board" required>
                      </div>
                    </td>
                    <td>
                      <div class="input">
                        <input type="text" name="tenthyop" id="tenthyop" value="<?php echo $result_formdetails['std_tenth_yop'];?>" placeholder="Year of Passing" required>
                      </div>
                    </td>
                    <td>
                      <div class="input">
                        <input type="text" name="tenthper" id="tenthper" value="<?php echo $result_formdetails['std_tenth_per'];?>" placeholder="Percentage (%)" required>
                      </div>
                    </td>
                  </tr>

                  <tr>
                    <td><label for="">12th <span class="required">*</span></td>
                    <td>
                      <div class="input">
                        <input type="text" name="twelveboard" id="twelveboard" value="<?php echo $result_formdetails['std_twelve_board'];?>" placeholder="12th Board" required>
                      </div>
                    </td>
                    <td>
                      <div class="input">
                        <input type="text" name="twelveyop" id="twelveyop" value="<?php echo $result_formdetails['std_twelve_yop'];?>" placeholder="Year of Passing" required>
                      </div>
                    </td>
                    <td>
                      <div class="input">
                        <input type="text" name="twelveper" id="twelveper" value="<?php echo $result_formdetails['std_twelve_per'];?>" placeholder="Percentage (%)" required>
                      </div>
                    </td>
                  </tr>
                </table>
              </div>
            </div>

            <h1>PROGRAMME / COURSE INFORMATION</h1>
            <div class="welcome">
        <p><span> </span> <span><b>UG</b> - Under Graduate Courses | <b>PG</b> - Post Graduate Courses</span></p>
      </div>
          
            <div class="input">

              <label for="course">Course <span class="required">*</span></label>
              <select name="course" id="course" required>
                <option value="">Select</option>
                <?php
                    $sql_fetchcourse = mysqli_query($conn,"SELECT * FROM `tbl_course` ORDER BY `id` DESC");
                    if(mysqli_num_rows($sql_fetchcourse) > 0)
                    {
                        while($result_fetchcourse = mysqli_fetch_assoc($sql_fetchcourse)){
                          echo "<option value='".$result_fetchcourse['id']."'";
                          
                          echo ($result_formdetails['std_courseid'] == $result_fetchcourse['id']) ? "selected": "";
                          
                          echo ">";

                          echo ($result_fetchcourse['course'] == "ug") ? "UG" : "PG";
                          
                          echo " - ".$result_fetchcourse['stream']."</option>";
                        }
                    }
                ?>
                
              </select>

             

             
            </div>


            <div class="input">
              <input type="submit" name="applynow" value="Update">
            </div>
          </form>
        </div>
      </div>
    </section>


  </div>



    <script src="assets/js/formvalidation.js"></script>
</body>

</html>


<?php
if(isset($_POST['applynow']))
{
  $bloodgroup = $_POST['bloodgroup'];
  $category = $_POST['category'];
  $religion = $_POST['religion'];
  $martialstatus = $_POST['martialstatus'];
  $fathername = $_POST['fathername'];
  $mothername = $_POST['mothername'];
  $parentemail = $_POST['email'];
  $parentphone = $_POST['phone'];
  $houseno = $_POST['houseno'];
  $village = $_POST['village'];
  $city = $_POST['city'];
  $state = $_POST['state'];
  $country = $_POST['country'];
  $pincode = $_POST['pincode'];
  $aadharcard = $_POST['aadharcard'];
  $tenthboard = $_POST['tenthboard'];
$tenthyop = $_POST['tenthyop'];
  $tenthper = $_POST['tenthper'];
  $twelveboard = $_POST['twelveboard'];
$twelveyop = $_POST['twelveyop'];
  $twelveper = $_POST['twelveper'];
  $courseid = $_POST['course'];

  $sql = mysqli_query($conn,"UPDATE `tbl_admission` SET `std_bloodgroup`='{$bloodgroup}',`std_category`='{$category}',`std_religion`='{$religion}',`std_martialstatus`='{$martialstatus}',`std_fathername`='{$fathername}',`std_mothername`='{$mothername}',`std_parentemail`='{$parentemail}',`std_parentphone`='{$parentphone}',`std_housenumber`='{$houseno}',`std_village`='{$village}',`std_city`='{$city}',`std_state`='{$state}',`std_country`='{$country}',`std_pincode`='{$pincode}',`std_aadharnumber`='{$aadharcard}',`std_tenth_board`='{$tenthboard}',`std_tenth_yop`='{$tenthyop}',`std_tenth_per`='{$tenthper}',`std_twelve_board`='{$twelveboard}',`std_twelve_yop`='{$twelveyop}',`std_twelve_per`='{$twelveper}',`std_courseid`='{$courseid}' WHERE `std_enrollid`='{$user_id}'");
  if($sql){
    echo "<script>alert('Updated !');
    window.location.replace(`edit.php`);</script>";
  }
}

?>