<script>
    window.location.replace('login.php');
</script>