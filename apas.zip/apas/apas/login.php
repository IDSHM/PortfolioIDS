<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login - APAS</title>

    <!-- Internal Css Files -->
    <link rel="stylesheet" href="assets/css/header.css" />
    <link rel="stylesheet" href="assets/css/register-form.css">

    <!-- Font-Awesome Icons -->
    <script
      src="https://kit.fontawesome.com/40963500f2.js"
      crossorigin="anonymous"
    ></script>
  </head>
  <body>
    <header>
      <div class="mini-nav">
        <div class="left">
          <div class="phone">
            <i class="fa-solid fa-phone"></i>&nbsp;
            <a href="#">0161-9999000/001</a>
          </div>
          <div class="email">
            <i class="fa-solid fa-envelope"></i>&nbsp;
            <a href="#">demo-mail@mail.com</a>
          </div>
        </div>

        <div class="right">
          <div class="social">
              <a href="#"><i class="fa-brands fa-facebook"></i></a>
              <a href="#"><i class="fa-brands fa-twitter"></i></a>
              <a href="#"><i class="fa-brands fa-instagram"></i></a>
              <a href="#"><i class="fa-brands fa-linkedin"></i></a>
          </div>
        </div>
      </div>

      <nav>
        <div class="logo">
          <img src="assets/logo.png" alt="" />
          <div class="collage-name">
            <a href="../">
                <!-- <p class="head-small"></p> -->
                <p class="head-big">Admission Process Automation System</p>
            </a>
          </div>
        </div>
        <div class="nav">
          <a href="../">Home</a>
          <a href="./register.php" class="login-btn">Register</a>
        </div>
      </nav>
    </header>


    <section>
        <div class="register">
            <h6>Login</h6>
            <div class="info">
                <p>Please fill in this form to Login.</p>

                <p class="required">* Required</p>
            </div>

            <div class="form">
                <form action="">
                  
                    <div class="input">
                        <label for="email">Email <span class="required">*</span></label>
                        <input type="email" id="email" name="email" placeholder="Enter Email" required>
                    </div>

                    <div class="input">
                        <label for="psw">Password <span class="required">*</span></label>
                        <input type="password" name="psw" id="psw" placeholder="Enter Password" required>
                        <input type="checkbox" name="showpsw" id="showpsw"><span class="show-password" value="1">Show Password</span>
                    </div>

                    <div class="errortext"></div>

                    
                    <div class="loading">
                      <div class="loader"></div>
                    </div>
              
                    <div class="input button">
                        <input type="submit" value="Login">
                    </div>

                    <span class="newregister">Donot have Account ? <a href="register.php">Sign Up</a>.</span>
                </form>
            </div>
        </div>
    </section>


    <script src="assets/js/showpassword.js"></script>
    <script src="assets/js/formvalidation.js"></script>

    <script src="assets/js/login.js"></script>
  </body>
</html>
