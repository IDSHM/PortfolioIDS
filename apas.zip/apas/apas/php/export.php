<?php 

    include_once "connection.php";
   $user_id = $_GET['id'];

   $sql_details = mysqli_query($conn,"SELECT `std_enrollid`, `std_datetime`, `std_name`, `std_gender`, `std_dob`, `std_email`, `std_phone` FROM `tbl_account` WHERE `std_enrollid` =  '{$user_id}'");
    if(mysqli_num_rows($sql_details) > 0)
    {
        $result_details = mysqli_fetch_assoc($sql_details);
    }

    $sql_formdetails = mysqli_query($conn,"SELECT * FROM `tbl_admission`");
    if(mysqli_num_rows($sql_formdetails) > 0)
    {
      $result_formdetails = mysqli_fetch_assoc($sql_formdetails);
    }


$html ='

  <!-- Internal Css Files -->
  <link rel="stylesheet" href="../assets/css/register-form.css">
  <link rel="stylesheet" href="../assets/css/header.css" />
  <link rel="stylesheet" href="../assets/css/dashboard.css">
  <link rel="stylesheet" href="../assets/css/admissionform.css">
  <link rel="stylesheet" href="../assets/css/uploaddocuments.css">

  <!-- Fancy Box -->
  <link rel="stylesheet" href="../assets/css/fancybox.css">



  <!-- Font-Awesome Icons -->
  <script src="https://kit.fontawesome.com/40963500f2.js" crossorigin="anonymous"></script>

  <style>
    section .basicdetails .table table td{
    border:1px solid #CCC9B6;
    margin:0;
}
section .basicdetails .table table th{
    width:200px;
}
  </style>
';


$html .= '<div class="container-fluid">
<section>
  <div class="welcome">
    <h2>Admission Process Automation System</h2>
    <p><span>ADMISSION FORM</span></p>
  </div>

  <section>
    <div class="basicdetails">
        <div class="table">
            <table border="0" style="border:none;">
            <tr>
                <td colspan="2" style="border:none;text-align:right;color:red;"><b>DateTime : </b>'.$result_formdetails['datetime'].'</td>
            </tr>
            <tr>
                <th>Form No.</th>
                <td style="color:red;"><b>'.$user_id.'</b></td>
            </tr></table>


            <table border="0" style="border:none;">
                <tr>
                    <th>Name</th>
                    <td>'.$result_details['std_name'].'</td>
                    <td rowspan="5" width="146px">
                        <img src="../documents/photo/'.$user_id.'.jpg" width="100%" height="100%" alt="">
                    </td>
                </tr>
                <tr>
                    <th>Age</th>
                    <td>';

                    

# object oriented
$from = date_create($result_details['std_dob']);
$to   = new DateTime('today');
$html .= ($from->diff($to)->y);

$html .= '</td>
</tr>
<tr>
    <th>Gender</th>
    <td>';
    
    $tjtmp = ($result_details['std_gender'] == "M") ? "Male" : "Female";
    
    $html .= $tjtmp;
    
    $html .= '</td>
</tr>
<tr>
    <th>DOB</th>
    <td>';

$date=date_create($result_details['std_dob']);
$html .= date_format($date,"d / M / Y");
        
    $html .= '</td>
</tr>
<tr>
    <th>Blood Group</th>
    <td>'.$result_formdetails['std_bloodgroup'].'</td>
</tr>
</table> <table border="0" style="border:none;">
<tr>
    <th>Category</th>
    <td width="265px">'.$result_formdetails['std_category'].'</td>
    <th>Religion</th>
    <td>'.$result_formdetails['std_religion'].'</td>
</tr>
<tr><th>Martial Status</th>
<td colspan="3">';

$tjtmp = ($result_formdetails['std_martialstatus'] == 1) ? "Married" : "Unmarried";

$html .= $tjtmp;



$html .= '</td>
</tr></table>

<table border="0" style="border:none;">
    <tr>
        <th>Email</th>
        <td>'.$result_details['std_email'].'</td>
    </tr>
<tr>
    <th>Phone</th>
    <td >'.$result_details['std_phone'].'</td>
</tr></table>

<table border="0" style="border:none;">
    <tr>
        <th>Father Name</th>
        <td>'.$result_formdetails['std_fathername'].'</td>
    </tr>
<tr>
    <th>Mother Name</th>
    <td >'.$result_formdetails['std_mothername'].'</td>
</tr>

<tr>
    <th>Parent Email</th>
    <td >'.$result_formdetails['std_parentemail'].'</td>
</tr>
<tr>
    <th>Parent Phone</th>
    <td >'.$result_formdetails['std_parentphone'].'</td>
</tr>
</table>

<table border="0" style="border:none;">
<tr>
    <th>House No.</th>
    <td width="265px">'.$result_formdetails['std_housenumber'].'</td>
    <th>Village / Locality</th>
    <td>'.$result_formdetails['std_village'].'</td>
</tr>
<tr>
    <th>City</th>
    <td width="265px">'.$result_formdetails['std_city'].'</td>
    <th>State</th>
    <td>'.$result_formdetails['std_state'].'</td>
</tr>
<tr>
    <th>Country</th>
    <td width="265px">'.$result_formdetails['std_country'].'</td>
    <th>Pin Code</th>
    <td>'.$result_formdetails['std_pincode'].'</td>
</tr>
</table>

<table border="0" style="border:none;">
<tr>
<th>Aadhar No.</th>
<td>'.$result_formdetails['std_aadharnumber'].'</td>
</tr>
</table><table border="0" style="border:none;">
<tr>
    <th>Exam Passed</th>
    <th>Board</th>
    <th >Year of Passing</th>
    <th>Percentage (%)</th>
  </tr>
  <tr>
    <td >10th</td>
    <td>'.$result_formdetails['std_tenth_board'].'</td>
    <td >'.$result_formdetails['std_tenth_yop'].'</td>
    <td>'.$result_formdetails['std_tenth_per'].'</td>
  </tr>
  <tr>
    <td>12th</td>
    <td>'.$result_formdetails['std_twelve_board'].'</td>
    <td>'.$result_formdetails['std_twelve_yop'].'</td>
    <td>'.$result_formdetails['std_twelve_per'].'</td>
  </tr>
</table>

<table border="0" style="border:none;">
<tr>
<th>Course</th>
<td>';
                
$courseid = $result_formdetails['std_courseid'];

 $sql_fetchcourse = mysqli_query($conn,"SELECT * FROM `tbl_course` WHERE `id` = '{$courseid}'");
 if(mysqli_num_rows($sql_fetchcourse) > 0)
 {
     $result_fetchcourse = mysqli_fetch_assoc($sql_fetchcourse);
       $tjtmp = ($result_fetchcourse['course'] == "ug") ? "UG" : "PG";
       $tjtmp .= " - ".$result_fetchcourse['stream'];
 }


 $html .= $tjtmp;

 $html .= '</td>
 </tr>
</table>

<table border="0" style="border:none;">
<tr>
   <th>Application</th>
   <td style="color:orange;"><b>Reviewing</b></td>
 </tr>
</table>
       </div>    
   </div>
</section>
</section>
<br><br><br><br><br><br>
<section style="padding-top:1px"><div class="register">
<div class="form">
  <form>
    <h1 style="color:#F03C02">Document Uploaded</h1>

    <div class="document">
      <div class="aadhar">
        <a class="img" data-fancybox="gallery" href="../documents/aadhar/'.$user_id.'.jpg">
        <img height="500px"  src="../documents/aadhar/'.$user_id.'.jpg" alt="" />
        </a>
                </div>
                <div class="tenth">
                <a class="img" data-fancybox="gallery" href="../documents/tenth/'.$user_id.'.jpg"> <img height="500px"  src="../documents/tenth/'.$user_id.'.jpg" alt="" />
                </a></div>
                <div class="twelve">
                <a class="img" data-fancybox="gallery" href="../documents/twelve/'.$user_id.'.jpg" > <img height="500px"  src="../documents/twelve/'.$user_id.'.jpg" alt="" />
                </a>   </div>
                </div>
              </form>
            </div>
          </div>
          
          
                 
  


</section>

</div>
' ;

echo $html;

// header('Content-Type:application/xls');
// header('Content-Disposition:attachment;filename=Ehsaas_'.$user_id.'.xls');


?>