<?php 
    session_start();
    include_once "connection.php";
    error_reporting(0);

    $email = mysqli_real_escape_String($conn, $_POST['email']);
    $psw = mysqli_real_escape_String($conn, $_POST['psw']);

    if(!empty($email) && !empty($psw)){
        $sql = mysqli_query($conn,"SELECT `std_enrollid`,`std_email`,`std_psw` FROM `tbl_account` WHERE `std_email` = '{$email}'"); 
        
        if (mysqli_num_rows($sql) != 0) {
            $result = mysqli_fetch_assoc($sql);
            
            if($psw == $result['std_psw'])
            {
                $_SESSION['std_enrollid'] = $result['std_enrollid'];
                    
                    echo "success";
            }
            else
            {
                echo "Incorrect Password !";
            }
        }else{
            echo "User Not Registered !";
        }
    }else{
        echo "All Fields Are Required !";
    }

?>