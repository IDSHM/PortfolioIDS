<?php
    session_start();
    if(isset($_SESSION['std_enrollid'])){
        session_unset();
                session_destroy();
        header("location:../login.php");
    }
?>