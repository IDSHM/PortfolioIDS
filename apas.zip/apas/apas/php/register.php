<?php 
    session_start();
    include_once "connection.php";
    error_reporting(0);

    // Set the new timezone
    date_default_timezone_set('Asia/Kolkata');
    $date = date('d-m-y h:i:s');
   
    $name = mysqli_real_escape_String($conn, $_POST['name']);
    $gender = mysqli_real_escape_String($conn, $_POST['gender']);
    $dob = mysqli_real_escape_String($conn, $_POST['dob']);
    $email = mysqli_real_escape_String($conn, $_POST['email']);
    $phone = mysqli_real_escape_String($conn, $_POST['phone']);
    $psw = mysqli_real_escape_String($conn, $_POST['psw']);

    
    if(!empty($name) && !empty($gender) && !empty($dob) && !empty($email) && !empty($phone) && !empty($psw)){

        $sql_usercheck = "SELECT `std_email` FROM `tbl_account` WHERE `std_email` = '{$email}' OR `std_phone` = '{$phone}'";
        $resultcheck = mysqli_query($conn,$sql_usercheck);
        if (mysqli_num_rows($resultcheck) == 0) {
            $sql = "INSERT INTO `tbl_account`(`std_datetime`, `std_name`, `std_gender`, `std_dob`, `std_email`, `std_phone`, `std_psw`) VALUES ('{$date}','{$name}','{$gender}','{$dob}','{$email}','{$phone}','{$psw}')";
            if(mysqli_query($conn, $sql))
            {
                $sql_userid = "SELECT `std_enrollid` FROM `tbl_account` WHERE `std_email` = '{$email}' AND `std_phone` = '{$phone}'";
                $result = mysqli_query($conn,$sql_userid);
                $row = mysqli_fetch_assoc($result);

                $user_id = $row['std_enrollid'];

                $sql_status = "INSERT INTO `tbl_status`(`std_enrollid`) VALUES ('{$user_id}')";
                if(mysqli_query($conn, $sql_status))
                {
                    $_SESSION['std_enrollid'] = $user_id;

                    if($email_status == 1){
                        echo "success_email";
                    }else{
                        echo "success";
                    }
                }else{
                    echo "Try Again !";
                }
            }
            else{
                echo "Try Again !";
            }
        }
        else{
            echo "User Already Exist !";
        }
    }
    else{
        echo "All Fields Are Required !";
    }
?>