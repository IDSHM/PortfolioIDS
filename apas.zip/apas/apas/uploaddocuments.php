<?php 
    session_start();
    include_once "php/connection.php";
  //  error_reporting(0);

  if(!isset($_SESSION['std_enrollid'])){
    echo '
    <script>window.location.replace("./login.php")</script>;
    ';
   }

   $user_id = $_SESSION['std_enrollid'];

   $sql_details = mysqli_query($conn,"SELECT `std_email` FROM `tbl_account` WHERE `std_enrollid` =  '{$user_id}'");
   if(mysqli_num_rows($sql_details) > 0)
   {
       $result_details = mysqli_fetch_assoc($sql_details);
   }

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Upload Document - APAS</title>

  <!-- Internal Css Files -->
  <link rel="stylesheet" href="assets/css/register-form.css" />
  <link rel="stylesheet" href="assets/css/header.css" />
  <link rel="stylesheet" href="assets/css/dashboard.css" />
  <link rel="stylesheet" href="assets/css/admissionform.css" />
  <link rel="stylesheet" href="assets/css/uploaddocuments.css">

  <!-- Font-Awesome Icons -->
  <script src="https://kit.fontawesome.com/40963500f2.js" crossorigin="anonymous"></script>
</head>

<body>
  <header>
    <div class="mini-nav">
      <div class="left">
        <div class="phone">
          <i class="fa-solid fa-phone"></i>&nbsp;
          <a href="#">0161-9999000/001</a>
        </div>
        <div class="email">
          <i class="fa-solid fa-envelope"></i>&nbsp;
          <a href="#">demo-mail@mail.com</a>
        </div>
      </div>

      <div class="right">
        <div class="social">
          <a href="#"><i class="fa-brands fa-facebook"></i></a>
          <a href="#"><i class="fa-brands fa-twitter"></i></a>
          <a href="#"><i class="fa-brands fa-instagram"></i></a>
          <a href="#"><i class="fa-brands fa-linkedin"></i></a>
        </div>
      </div>
    </div>

    <nav>
      <div class="logo">
        <img src="assets/logo.png" alt="" />
        <div class="collage-name">
          <a href="#">
            <!-- <p class="head-small"></p> -->
            <p class="head-big">Admission Process Automation System</p>
          </a>
        </div>
      </div>
      <div class="nav">
      </div>
    </nav>
  </header>

  <div class="container">
  <section>
      <div class="welcome">
        <h2>Upload Documents</h2>
        <p>
          <span>Get Your Self Registered with APAS</span>
          <span>* Required</span>
        </p>
      </div>
</section>
  <section>
              <div class="welcome">
                      <h2 style="color:black">Important Instructions</h2>
                      <p >
                        <ul style="margin:0px 20px;">
                          <li style="margin:5px 0px;">Please Upload Documents For Further Process.</li>
                          <li style="margin:5px 0px;"><b><b>Only Image File Accepted (.jpg, .jpeg, .png).</b></b></li>
                          <li style="margin:5px 0px;"><b><b>Max File Size 200KB.</b></b></li>
                        </ul>
                      </p>
                  </div>
              </section>

   

<section style="padding-top:1px">

      <div class="register">
        <div class="form">
          <form action="" method="POST" enctype="multipart/form-data">
            <h1>Document Upload</h1>

            <div class="document">
              <div class="aadhar">
                <div class="img">
                  <img id="outputaadhar"  src="" alt="" />
                </div>
                <div class="upload">
                  <input type="file" accept="image/*" name="aadharimg" onchange="loadFilep(event,0)" required />
                  <p><span>*</span> Aadhar Card</p>
                </div>
              </div>
              <div class="tenth">
                <div class="img">
                  <img id="outputtenth"  src="" alt="" />
                </div>
                <div class="upload">
                  <input type="file" accept="image/*" name="tenthimg" onchange="loadFilep(event,1)" required />
                  <p><span>*</span> 10th Certificate</p>
                </div>
              </div>
              <div class="twelve">
                <div class="img">
                  <img id="outputwelve" src="" alt="" />
                </div>
                <div class="upload">
                  <input type="file" accept="image/*" name="twelveimg" onchange="loadFilep(event,2)" required />
                  <p><span>*</span> 12th Certificate</p>
                </div>
              </div>
            </div>

            <div style="margin:60px 0 0 0;">
            <input type="radio" value="1" name="confirm" required> I Confirm that all the Uploaded Documents above is Correct.
                <br>
            </div>

            <div class="input">
              <input type="submit" name="uploaddocuments" value="Upload" />
            </div>
          </form>
        </div>
      </div>
    </section>

  



  </div>
  <script>
    var loadFilep = function (event,picid) {
      var out = ["outputaadhar", "outputtenth","outputwelve"];
      var output = document.getElementById(out[picid]);
      if(event.target.files[0].size < 250000){
      output.src = URL.createObjectURL(event.target.files[0]);
      output.style.height = "500px";
        output.onload = function () {
        URL.revokeObjectURL(output.src); // free memory
      };
      }else{
        alert("File size too large. File must be less than 200KB.");
        output.src = "assets/noimgverticalred.png";
      output.style.height = "500px";
        output.onload = function () {
        URL.revokeObjectURL(output.src); // free memory
      };
      }
    };
  </script>
</body>

</html>


<?php
if(isset($_POST['uploaddocuments']))
{

  $confirm = $_POST['confirm'];
  
  $filename = $user_id;
  $filename .= ".jpg";

  // aadhar card
  $tempname_aadharcard = $_FILES["aadharimg"]["tmp_name"];
  $folder_aadharcard = "documents/aadhar/".$filename;
  move_uploaded_file($tempname_aadharcard,$folder_aadharcard);

  // tenth card
  $tempname_tenth = $_FILES["tenthimg"]["tmp_name"];
  $folder_tenth= "documents/tenth/".$filename;
  move_uploaded_file($tempname_tenth,$folder_tenth);

  // twelve card
  $tempname_twelve = $_FILES["twelveimg"]["tmp_name"];
  $folder_twelve = "documents/twelve/".$filename;
  move_uploaded_file($tempname_twelve,$folder_twelve);

  $file_size_aad = $_FILES["aadharimg"]['size'];
  $file_size_ten = $_FILES["tenthimg"]['size'];
  $file_size_twe = $_FILES["tenthimg"]['size'];

if (($file_size_aad  > 250000) || ($file_size_ten > 250000) || ($file_size_twe > 250000) ){      
    echo '<script type="text/javascript">alert("File size too large. File must be less than 200KB.");</script>'; 
}else{
  $sql_profiepicupload = "UPDATE `tbl_status` SET `std_documentupload`='1' WHERE `std_enrollid` = {$user_id}";
if(mysqli_query($conn,$sql_profiepicupload) && $confirm == 1){




  // Email System
  if($email_status == 0){
    echo "<script>alert('Document Uploaded !!!');
  window.location.replace(`dashboard.php`);</script>";
  }else{
    echo '

    <script type="text/javascript"
    src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>
    
    <script>

  
  
    emailjs.init("JZXjyLlOrXEB1DddM");

    emailjs.send("service_pozrraa","template_8s7uztn",{
      subject: `Document Upload - APAS`,
      to: `'.$result_details["std_email"].'`,
      msg1: `We have Received your Documents and Your Application is now sent for Review.`,
      msg2: ``,
      msg3: `Please Do Check your Inbox on Daily Basis for Further Notice...!`,
      msg4: ``,
      msg5: ``,
      link: ``,
    }).then(() => {
      alert("Document Uploaded !!! Check Your Inbox !");
            location.href="dashboard.php";
      },(err) => {
        alert("Document Uploaded !!!");
          location.href="dashboard.php";
  });

    </script>';
  }



}
}
}
?>

