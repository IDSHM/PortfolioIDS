let collageName = document.querySelector("#header .logo span a");
console.log(collageName.innerHTML);

setInterval(()=>{
    if(988 < window.innerWidth && window.innerWidth < 1465){
        collageName.innerHTML = "APAS";
        collageName.style.fontSize = "28px";
    }else{
        collageName.innerHTML = "College Admission <br>Process Automation System";
        collageName.style.fontSize = "1em";
    }
},1000)


